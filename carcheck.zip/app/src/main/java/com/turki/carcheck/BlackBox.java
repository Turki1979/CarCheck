package com.turki.carcheck;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** الصندوق الأسود: يحفظ آخر دقيقة دايماً، ولما يصير حدث يكمّل ٣٠ ثانية بعده ويحفظ الملف */
public class BlackBox {

    public static final String[] COLS = {"الوقت", "السرعة", "الدوران", "حرارة الماء", "حرارة القير", "الحمل",
            "الجهد", "خليط ج١", "خليط ج٢", "الثروتل المطلوب", "الثروتل الفعلي", "هواء MAF"};

    private final File dir;
    private final ArrayDeque<float[]> ring = new ArrayDeque<>();
    private List<float[]> capture;
    private float eventT;
    private String reason;
    private long eventWall;

    public BlackBox(File base) {
        dir = new File(base, "blackbox");
        dir.mkdirs();
    }

    public synchronized void add(float[] row) {
        ring.addLast(row);
        while (!ring.isEmpty() && row[0] - ring.peekFirst()[0] > 60) ring.pollFirst();
        if (capture != null) {
            capture.add(row);
            if (row[0] - eventT >= 30) save();
        }
    }

    public synchronized boolean trigger(String why, float now) {
        if (capture != null) return false;
        capture = new ArrayList<>(ring);
        eventT = now;
        reason = why;
        eventWall = System.currentTimeMillis();
        return true;
    }

    public synchronized boolean recording() {
        return capture != null;
    }

    /** يحفظ اللي انلقط (يُستدعى أيضاً عند الفصل) */
    public synchronized void save() {
        if (capture == null) return;
        try {
            String name = "bb_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date(eventWall)) + ".csv";
            FileWriter w = new FileWriter(new File(dir, name));
            w.write("# " + reason.replace("\n", " ") + "\n");
            w.write("# " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(eventWall)) + "\n");
            w.write(String.join(",", COLS) + "\n");
            for (float[] r : capture) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < r.length; i++) {
                    if (i > 0) sb.append(',');
                    float v = i == 0 ? r[i] - eventT : r[i];
                    if (!Float.isNaN(v)) sb.append(String.format(Locale.US, i == 6 ? "%.2f" : "%.1f", v));
                }
                w.write(sb.append('\n').toString());
            }
            w.close();
            File[] all = dir.listFiles();
            if (all != null && all.length > 40) {
                Arrays.sort(all);
                for (int i = 0; i < all.length - 40; i++) all[i].delete();
            }
        } catch (Exception ignored) {
        }
        capture = null;
    }

    public List<File> files() {
        File[] all = dir.listFiles();
        List<File> out = new ArrayList<>();
        if (all == null) return out;
        Arrays.sort(all);
        for (int i = all.length - 1; i >= 0; i--) out.add(all[i]);
        return out;
    }

    /** يرجع {السبب، التاريخ، الصفوف} */
    public static Object[] load(File f) {
        String why = "", when = "";
        List<float[]> rows = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            int hdr = 0;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("#")) {
                    if (hdr++ == 0) why = line.substring(1).trim();
                    else when = line.substring(1).trim();
                    continue;
                }
                if (line.startsWith(COLS[0])) continue;
                String[] p = line.split(",", -1);
                float[] v = new float[COLS.length];
                for (int i = 0; i < v.length; i++) {
                    try {
                        v[i] = i < p.length && !p[i].isEmpty() ? Float.parseFloat(p[i]) : Float.NaN;
                    } catch (NumberFormatException e) {
                        v[i] = Float.NaN;
                    }
                }
                rows.add(v);
            }
        } catch (Exception ignored) {
        }
        return new Object[]{why, when, rows};
    }

    public static String text(File f) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            int k = 0;
            while ((line = r.readLine()) != null) {
                // نخفف البيانات للمشاركة: كل صف ثاني
                if (line.startsWith("#") || line.startsWith(COLS[0]) || (k++ % 2 == 0)) sb.append(line).append('\n');
            }
        } catch (Exception ignored) {
        }
        return sb.toString();
    }
}
