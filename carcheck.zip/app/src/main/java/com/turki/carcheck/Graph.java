package com.turki.carcheck;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** رسم بياني بسيط: كل خط له مقياسه الخاص، والوسيلة فوق */
public class Graph extends View {

    private static class Line {
        String name;
        int color;
        float[] y;
    }

    private float[] x = new float[0];
    private String xUnit = "";
    private final List<Line> lines = new ArrayList<>();
    private float mark = Float.NaN;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public Graph(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    public void setX(float[] x, String unit) {
        this.x = x;
        this.xUnit = unit;
        lines.clear();
    }

    public void add(String name, int color, float[] y) {
        Line l = new Line();
        l.name = name;
        l.color = color;
        l.y = y;
        lines.add(l);
        invalidate();
    }

    public void setMark(float xm) {
        mark = xm;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(200 * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        float top = 22 * d * Math.max(1, (lines.size() + 1) / 2), bot = H - 16 * d, left = 6 * d, right = W - 6 * d;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x10FFFFFF);
        c.drawRect(left, top, right, bot, p);
        p.setTextSize(11 * d);
        // الوسيلة
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            float mn = Float.MAX_VALUE, mx = -Float.MAX_VALUE;
            for (float v : l.y)
                if (!Float.isNaN(v)) {
                    mn = Math.min(mn, v);
                    mx = Math.max(mx, v);
                }
            String rng = mn <= mx ? String.format(Locale.US, " (%.0f–%.0f)", mn, mx) : " (--)";
            p.setColor(l.color);
            float lx = (i % 2 == 0) ? right - 4 * d : W / 2 - 4 * d;
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("■ " + l.name + rng, lx, 14 * d + (i / 2) * 18 * d, p);
        }
        if (x.length < 2) {
            p.setColor(0xFF9FB2CC);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("ما فيه بيانات", W / 2, (top + bot) / 2, p);
            return;
        }
        float x0 = x[0], x1 = x[x.length - 1];
        if (x1 <= x0) x1 = x0 + 1;
        // المحور الأفقي
        p.setColor(0xFF9FB2CC);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(String.format(Locale.US, "%.0f", x0), left, H - 3 * d, p);
        p.setTextAlign(Paint.Align.RIGHT);
        c.drawText(String.format(Locale.US, "%.0f %s", x1, xUnit), right, H - 3 * d, p);
        if (!Float.isNaN(mark)) {
            float mxp = left + (mark - x0) / (x1 - x0) * (right - left);
            p.setColor(0xAAFF5A5F);
            p.setStrokeWidth(2 * d);
            c.drawLine(mxp, top, mxp, bot, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * d);
        for (Line l : lines) {
            float mn = Float.MAX_VALUE, mx = -Float.MAX_VALUE;
            for (float v : l.y)
                if (!Float.isNaN(v)) {
                    mn = Math.min(mn, v);
                    mx = Math.max(mx, v);
                }
            if (mn > mx) continue;
            if (mx - mn < 1) {
                mx += 0.5f;
                mn -= 0.5f;
            }
            p.setColor(l.color);
            float px = Float.NaN, py = Float.NaN;
            int n = Math.min(x.length, l.y.length);
            for (int i = 0; i < n; i++) {
                float v = l.y[i];
                if (Float.isNaN(v)) {
                    px = Float.NaN;
                    continue;
                }
                float sx = left + (x[i] - x0) / (x1 - x0) * (right - left);
                float sy = bot - 4 * d - (v - mn) / (mx - mn) * (bot - top - 8 * d);
                if (!Float.isNaN(px)) c.drawLine(px, py, sx, sy, p);
                px = sx;
                py = sy;
            }
        }
        p.setStyle(Paint.Style.FILL);
    }
}
