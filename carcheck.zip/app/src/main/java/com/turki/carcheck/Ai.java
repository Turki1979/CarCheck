package com.turki.carcheck;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

/** يرسل التقرير لتطبيق Claude (أو أي تطبيق ذكاء) مع سؤال جاهز */
public class Ai {

    public static final String PROMPT = "عندي فورد إيدج 2011 محرك 3.5 V6 وقير 6F50. هذا تقرير من تطبيق فحص OBD سويته. "
            + "حلّل الحالة بالعربي البسيط: وش المشاكل المحتملة، وش خطورة كل وحدة، ووش أسوي أو وش أقول للفني. "
            + "انتبه لعيوب إيدج المعروفة (مضخة الماء الداخلية، الثروتل، الـPTU ومبرّد القير).\n\n";

    public static void ask(Context c, String data) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, PROMPT + data);
        Intent claude = new Intent(i).setPackage("com.anthropic.claude");
        PackageManager pm = c.getPackageManager();
        if (claude.resolveActivity(pm) != null) {
            c.startActivity(claude);
        } else {
            c.startActivity(Intent.createChooser(i, "أرسل التقرير لتطبيق الذكاء الاصطناعي"));
        }
    }
}
