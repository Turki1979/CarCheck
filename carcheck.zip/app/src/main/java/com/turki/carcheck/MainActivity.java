package com.turki.carcheck;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.text.InputType;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int BG = 0xFF0A1424, CARD = 0x14FFFFFF, STROKE = 0x29FFFFFF;
    private static final int TEXT = 0xFFEEF3FA, SUB = 0xFF9FB2CC, BLUE = 0xFF2D7FF9;
    private static final int GREEN = 0xFF4ADE80, AMBER = 0xFFFFB020, RED = 0xFFFF5A5F;

    private SharedPreferences prefs;
    private TextView tvStatus, btnConnect, btnTest, tvScore, tvScoreLabel, tvReasons, tvCodes, tvTime;
    private TextView vCool, vTrans, vRpm, vSpeed, vVolt, vLoad, vTrim, vIat;
    private ToneGenerator tone;

    private final Obd obd = new Obd();
    private volatile boolean connected, testing, stop;
    private Thread worker;

    // قراءات حالية
    private volatile Integer cool, trans, rpm, speed, load, iat;
    private volatile Double volt, stft, ltft;
    private volatile boolean transSupported = true;
    private String transHeader;
    private int transTries;

    // إحصائيات المشوار
    private long testStart;
    private int maxCool = Integer.MIN_VALUE, maxTrans = Integer.MIN_VALUE, maxRpm;
    private int coolAfter10Min = Integer.MIN_VALUE;
    private double sumTrim, sumVolt;
    private int nTrim, nVolt;
    private double idleSum, idleSq;
    private int idleN;
    private double distanceKm;
    private long lastSpeedT;
    private final Set<String> stored = new LinkedHashSet<>(), pending = new LinkedHashSet<>(), seen = new LinkedHashSet<>();
    private long lastDtcCheck;

    // ── سلاسة القير ──
    private TextView tvGearScore, tvGearInfo, tvFan;
    private SensorManager sm;
    private final java.util.ArrayDeque<double[]> samples = new java.util.ArrayDeque<>(); // [t, rpm, speed, ratio]
    private final java.util.ArrayDeque<double[]> jolts = new java.util.ArrayDeque<>();   // [t, jerk]
    private double lastAccMag = -1;
    private long lastAccT;
    private double stableRatio = -1;
    private long stableSince;
    private int upshifts, downshifts, flares, harsh;
    private double shiftTimeSum;

    // ── المراوح ──
    private int idleSamples, idleRising, maxIdleCool = Integer.MIN_VALUE;
    private Integer idleStartCool;
    private long idleStartT;
    private int idleEpisodes, badIdleEpisodes;
    private double prevCoolForFan = Double.NaN;
    private volatile boolean baselineDone;

    // ── الجهة الثانية للخليط ──
    private volatile Double stft2, ltft2;
    private double sumTrim2;
    private int nTrim2;
    private double warmCoolSum;
    private int warmCoolN;

    // ── الدينمو تحت الحمل ──
    private double idleVSum, cruiseVSum, minRunV = 99;
    private int idleVN, cruiseVN;

    // ── تقطيع البساتم ──
    private final int[][] mis = new int[6][];
    private volatile boolean misSupported = true, needMisfire = true;
    private int misFail;
    private long lastMisfire;

    // ── البطارية ──
    private volatile boolean paused, batteryRunning;

    // ── الصوت ──
    private TextToSpeech tts;
    private volatile boolean ttsOk;
    private boolean voiceOn = true;
    private long lastFlareSay;
    private TextView btnVoice;

    // ── الثروتل ──
    private volatile Integer thrCmd, thrAct;
    private volatile Double maf;
    private double thrOff;
    private int thrN, thrBadRun, thrBad, thrMoves;
    private Integer prevThrCmd;
    private long thrJumpT;
    private int thrJumpFrom, thrJumpDir;
    private double thrLagSum;
    private int thrLagN;

    // ── حارس المضخة ──
    private long warmStartT;
    private double warmMin = -1;
    private double cruiseCoolSum, cruiseCoolSq;
    private int cruiseCoolN;

    // ── البنزين والعداد و٠-١٠٠ ──
    private double fuelL, odoAdd;
    private long lastTrackT, lastOdoSave;
    private boolean accArmed;
    private long accStart;
    private int accMaxSpeed;
    private TextView tvTrip, tvMaint, tvEdge, tvDiag;

    // ── الصندوق الأسود والسجل ──
    private BlackBox bb;
    private long lastBbT, lastSeriesT;
    private JSONArray series = new JSONArray();

    // ── التشخيص ──
    private volatile boolean needDiag = true;
    private volatile String readyText = "", monText = "", freezeText = "";
    private boolean freezeDone;

    // ── البصمة ──
    private String printResult = "";
    private TextView tvMech, tvElec, tvPrint, tvAbs;
    private volatile String absText = "";
    private long lastWarnCool, lastWarnTrans, lastWarnVolt;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("carcheck", MODE_PRIVATE);
        voiceOn = prefs.getBoolean("voice", true);
        bb = new BlackBox(getFilesDir());
        buildUi();
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("ar", "SA"));
                if (r < 0) r = tts.setLanguage(new Locale("ar"));
                ttsOk = r >= 0;
                runOnUiThread(this::updateVoiceBtn);
            }
        });
        try {
            tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        } catch (Exception ignored) {
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
        }
    }

    // ───────────── الواجهة ─────────────

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable box(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, int fill, int color) {
        TextView t = text(s, 16, color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(14), dp(12), dp(14));
        t.setBackground(box(fill, fill == BLUE ? 0 : STROKE, 16));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(box(CARD, STROKE, 16));
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        return c;
    }

    private LinearLayout.LayoutParams mt(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(top);
        return lp;
    }

    private TextView tile(LinearLayout row, String label, String unit) {
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(text(label, 12, SUB));
        TextView v = text("--", 28, TEXT);
        c.addView(v);
        c.addView(text(unit, 11, SUB));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(dp(4), 0, dp(4), 0);
        row.addView(c, lp);
        for (int i = 0; i < c.getChildCount(); i++) ((TextView) c.getChildAt(i)).setGravity(Gravity.CENTER);
        return v;
    }

    private LinearLayout row(LinearLayout root) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(r, mt(8));
        return r;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        sv.addView(root);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("اختبار القيادة", 22, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tvStatus = text("● غير متصل", 13, RED);
        tvStatus.setPadding(dp(12), dp(6), dp(12), dp(6));
        tvStatus.setBackground(box(0x22FF5A5F, 0, 14));
        head.addView(tvStatus);
        root.addView(head);

        tvTime = text("وصّل المحوّل وشغّل السيارة، بعدين اضغط اتصال", 13, SUB);
        root.addView(tvTime, mt(6));

        LinearLayout btns = new LinearLayout(this);
        btnConnect = button("اتصال", 0x14FFFFFF, TEXT);
        btnTest = button("ابدأ الاختبار", BLUE, 0xFFFFFFFF);
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        b1.setMargins(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f);
        b2.setMargins(dp(4), 0, dp(4), 0);
        btns.addView(btnConnect, b1);
        btns.addView(btnTest, b2);
        root.addView(btns, mt(14));
        btnConnect.setOnClickListener(v -> onConnectClick());
        btnTest.setOnClickListener(v -> onTestClick());

        // التقييم
        LinearLayout sc = card();
        LinearLayout sh = new LinearLayout(this);
        sh.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        st.addView(text("تقييم المكينة", 14, SUB));
        tvScoreLabel = text("ابدأ الاختبار وامشِ ٥ دقايق على الأقل", 13, SUB);
        st.addView(tvScoreLabel);
        sh.addView(st, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tvScore = text("--", 44, TEXT);
        tvScore.setTypeface(Typeface.DEFAULT_BOLD);
        sh.addView(tvScore);
        sc.addView(sh);
        tvReasons = text("", 13, TEXT);
        tvReasons.setLineSpacing(0, 1.3f);
        sc.addView(tvReasons, mt(6));
        root.addView(sc, mt(14));

        // سلاسة القير
        LinearLayout gc = card();
        LinearLayout gh = new LinearLayout(this);
        gh.setGravity(Gravity.CENTER_VERTICAL);
        gh.addView(text("سلاسة القير", 14, SUB), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tvGearScore = text("--", 30, TEXT);
        tvGearScore.setTypeface(Typeface.DEFAULT_BOLD);
        gh.addView(tvGearScore);
        gc.addView(gh);
        tvGearInfo = text("ثبّت الجوال في الحامل عشان يقيس الرجّة", 13, SUB);
        tvGearInfo.setLineSpacing(0, 1.3f);
        gc.addView(tvGearInfo, mt(4));
        root.addView(gc, mt(10));

        // المراوح
        LinearLayout fc = card();
        fc.addView(text("قوة المراوح (التبريد وأنت واقف)", 14, SUB));
        tvFan = text("يحتاج وقفة دقيقة تقريباً والمحرك حار", 13, TEXT);
        tvFan.setLineSpacing(0, 1.3f);
        fc.addView(tvFan, mt(4));
        root.addView(fc, mt(10));

        // الميكانيكا
        LinearLayout mc = card();
        mc.addView(text("الميكانيكا: تقطيع البساتم والخليط", 14, SUB));
        tvMech = text("يقرأ بعد الاتصال", 13, SUB);
        tvMech.setLineSpacing(0, 1.3f);
        mc.addView(tvMech, mt(4));
        root.addView(mc, mt(10));

        // حارس إيدج
        LinearLayout gcard = card();
        gcard.addView(text("🛡️ حارس إيدج (أعطالها المعروفة)", 14, SUB));
        tvEdge = text("", 13, TEXT);
        tvEdge.setLineSpacing(0, 1.3f);
        gcard.addView(tvEdge, mt(4));
        TextView btnPump = button("سجّل فحص الماء والزيت", 0x14FFFFFF, TEXT);
        gcard.addView(btnPump, mt(10));
        btnPump.setOnClickListener(v -> pumpCheckDialog());
        root.addView(gcard, mt(10));

        // تشخيص الكمبيوتر
        LinearLayout dcard = card();
        dcard.addView(text("فحوصات الكمبيوتر: الجاهزية والدبة والحساسات", 14, SUB));
        tvDiag = text("يقرأ بعد الاتصال", 13, SUB);
        tvDiag.setLineSpacing(0, 1.3f);
        dcard.addView(tvDiag, mt(4));
        root.addView(dcard, mt(10));

        // الكهرباء
        LinearLayout ec = card();
        ec.addView(text("الكهرباء: البطارية والدينمو", 14, SUB));
        tvElec = text("", 13, TEXT);
        tvElec.setLineSpacing(0, 1.3f);
        ec.addView(tvElec, mt(4));
        TextView btnBat = button("فحص البطارية وقت التشغيل", 0x14FFFFFF, TEXT);
        ec.addView(btnBat, mt(10));
        btnBat.setOnClickListener(v -> batteryTest());
        root.addView(ec, mt(10));

        // البصمة
        LinearLayout pc = card();
        pc.addView(text("بصمة المكينة (مقارنة بعادة سيارتك)", 14, SUB));
        tvPrint = text("", 13, TEXT);
        tvPrint.setLineSpacing(0, 1.3f);
        pc.addView(tvPrint, mt(4));
        pc.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this).setTitle("تصفير البصمة؟")
                    .setMessage("يمسح المشاوير المرجعية ويبدأ يتعلّم من جديد (مثلاً بعد صيانة كبيرة).")
                    .setPositiveButton("صفّر", (d, w) -> {
                        prefs.edit().remove("base").apply();
                        printResult = "";
                        refreshExtra();
                    }).setNegativeButton("إلغاء", null).show();
            return true;
        });
        root.addView(pc, mt(10));

        // المشوار والبنزين و٠-١٠٠
        LinearLayout tc = card();
        tc.addView(text("⛽ البنزين والتسارع", 14, SUB));
        tvTrip = text("", 13, TEXT);
        tvTrip.setLineSpacing(0, 1.3f);
        tc.addView(tvTrip, mt(4));
        root.addView(tc, mt(10));

        // الصيانة
        LinearLayout mtc = card();
        mtc.addView(text("🔧 الصيانة", 14, SUB));
        tvMaint = text("", 13, TEXT);
        tvMaint.setLineSpacing(0, 1.3f);
        mtc.addView(tvMaint, mt(4));
        TextView btnMaint = button("تحديث العداد والصيانة", 0x14FFFFFF, TEXT);
        mtc.addView(btnMaint, mt(10));
        btnMaint.setOnClickListener(v -> maintDialog());
        root.addView(mtc, mt(10));

        // القراءات
        LinearLayout r1 = row(root);
        vCool = tile(r1, "حرارة الماء", "مئوية");
        vTrans = tile(r1, "حرارة زيت القير", "مئوية");
        LinearLayout r2 = row(root);
        vSpeed = tile(r2, "السرعة", "كم/س");
        vRpm = tile(r2, "الدوران", "RPM");
        LinearLayout r3 = row(root);
        vVolt = tile(r3, "البطارية / الدينمو", "فولت");
        vLoad = tile(r3, "حمل المحرك", "%");
        LinearLayout r4 = row(root);
        vTrim = tile(r4, "الخليط ج١ / ج٢", "%  (الطبيعي ±10)");
        vIat = tile(r4, "حرارة الهواء الداخل", "مئوية");

        // الأعطال
        LinearLayout cc = card();
        cc.addView(text("الأعطال (تنفحص كل دقيقة)", 14, SUB));
        tvCodes = text("ما تم الفحص للحين", 14, TEXT);
        tvCodes.setLineSpacing(0, 1.3f);
        cc.addView(tvCodes, mt(6));
        root.addView(cc, mt(14));

        tvAbs = text("الفرامل ABS والثبات: اضغط \"افحص أكواد الـABS\"", 13, SUB);
        tvAbs.setLineSpacing(0, 1.3f);
        cc.addView(tvAbs, mt(10));

        TextView btnAbs = button("افحص أكواد الـABS (الفرامل والثبات)", 0x14FFFFFF, TEXT);
        root.addView(btnAbs, mt(10));
        btnAbs.setOnClickListener(v -> readAbs());

        TextView btnRead = button("افحص الأعطال الحين", 0x14FFFFFF, TEXT);
        root.addView(btnRead, mt(10));
        btnRead.setOnClickListener(v -> checkCodesNow());

        TextView btnClear = button("مسح الأعطال", 0x33D7263D, 0xFFFF8A95);
        root.addView(btnClear, mt(10));
        btnClear.setOnClickListener(v -> confirmClear());

        TextView btnAi = button("🧠 اسأل الذكاء الاصطناعي عن سيارتي", BLUE, 0xFFFFFFFF);
        root.addView(btnAi, mt(10));
        btnAi.setOnClickListener(v -> Ai.ask(this, report()));

        TextView btnMark = button("📌 سجّل اللحظة (صار شي غريب)", 0x14FFFFFF, TEXT);
        root.addView(btnMark, mt(10));
        btnMark.setOnClickListener(v -> {
            if (!connected) {
                Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean ok = bb.trigger("تسجيل يدوي: صار شي غريب", SystemClock.elapsedRealtime() / 1000f);
            Toast.makeText(this, ok ? "انحفظت الدقيقة اللي فاتت، ويكمّل ٣٠ ثانية" : "فيه تسجيل شغال الحين", Toast.LENGTH_LONG).show();
        });

        TextView btnHist = button("📊 السجل والصندوق الأسود", 0x14FFFFFF, TEXT);
        root.addView(btnHist, mt(10));
        btnHist.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        TextView btnShare = button("مشاركة التقرير", 0x14FFFFFF, TEXT);
        root.addView(btnShare, mt(10));
        btnShare.setOnClickListener(v -> shareReport());

        btnVoice = button("", 0x14FFFFFF, TEXT);
        root.addView(btnVoice, mt(10));
        btnVoice.setOnClickListener(v -> {
            voiceOn = !voiceOn;
            prefs.edit().putBoolean("voice", voiceOn).apply();
            updateVoiceBtn();
            if (voiceOn) say("المساعد الصوتي شغال");
        });
        updateVoiceBtn();

        TextView note = text("تنبيه: لا تستخدم الجوال وأنت تسوق. ثبّته وخلّه يشتغل، والتطبيق ينبّهك بصوت.", 12, SUB);
        root.addView(note, mt(14));

        setContentView(sv);
        refreshExtra();
    }

    private void updateVoiceBtn() {
        if (btnVoice == null) return;
        btnVoice.setText(!voiceOn ? "🔇 المساعد الصوتي: مقفل" : ttsOk ? "🔊 المساعد الصوتي: شغال"
                : "🔊 المساعد الصوتي: نزّل الصوت العربي من إعدادات الجوال (تحويل النص لكلام)");
    }

    /** يتكلم بالعربي */
    private void say(String msg) {
        if (!voiceOn || !ttsOk || tts == null) return;
        String m = msg.replace("°", " درجة").replaceAll("[✓✗⚠●○•—]", " ").replace("/", " ");
        tts.speak(m, TextToSpeech.QUEUE_ADD, null, "w" + System.nanoTime());
    }

    // ───────────── الاتصال ─────────────

    private void onConnectClick() {
        if (connected) {
            disconnect();
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            return;
        }
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            Toast.makeText(this, "شغّل البلوتوث أول", Toast.LENGTH_LONG).show();
            return;
        }
        final List<BluetoothDevice> list = new ArrayList<>();
        List<String> names = new ArrayList<>();
        try {
            for (BluetoothDevice d : ad.getBondedDevices()) {
                list.add(d);
                String n = d.getName();
                names.add((n != null ? n : "جهاز") + "\n" + d.getAddress());
            }
        } catch (SecurityException e) {
            return;
        }
        if (list.isEmpty()) {
            Toast.makeText(this, "اربط المحوّل من إعدادات البلوتوث أول (الرمز غالباً 1234)", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("اختر محوّل OBD")
                .setItems(names.toArray(new String[0]), (d, w) -> {
                    String addr = list.get(w).getAddress();
                    prefs.edit().putString("addr", addr).apply();
                    connect(addr);
                })
                .show();
    }

    private void setStatus(String s, int color) {
        runOnUiThread(() -> {
            tvStatus.setText(s);
            tvStatus.setTextColor(color);
            tvStatus.setBackground(box((color & 0x00FFFFFF) | 0x22000000, 0, 14));
        });
    }

    private void connect(String addr) {
        setStatus("● جاري الاتصال...", AMBER);
        new Thread(() -> {
            try {
                obd.connect(addr);
                setStatus("● يتعرف على السيارة...", AMBER);
                if (!obd.init()) throw new Exception("المحوّل اتصل بس السيارة ما ردّت. تأكد إن الإشعال شغال");
                connected = true;
                setStatus("● متصل", GREEN);
                runOnUiThread(() -> btnConnect.setText("فصل"));
                stop = false;
                worker = new Thread(this::loop, "obd-loop");
                worker.start();
            } catch (Exception e) {
                obd.close();
                connected = false;
                setStatus("● غير متصل", RED);
                runOnUiThread(() -> Toast.makeText(this, "فشل الاتصال: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void disconnect() {
        if (bb != null) bb.save();
        stop = true;
        testing = false;
        connected = false;
        obd.close();
        setStatus("● غير متصل", RED);
        btnConnect.setText("اتصال");
        btnTest.setText("ابدأ الاختبار");
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ───────────── القراءة المستمرة ─────────────

    private void loop() {
        int n = 0;
        while (!stop) {
            if (paused) {
                Obd.sleep(50);
                continue;
            }
            try {
                int[] b;
                if (needMisfire || (testing && SystemClock.elapsedRealtime() - lastMisfire > 120000)) readMisfire();
                if (needDiag) readDiag();
                b = obd.pid("010D", "410D", 1);
                speed = b != null ? b[0] : null;
                b = obd.pid("010C", "410C", 2);
                rpm = b != null ? (b[0] * 256 + b[1]) / 4 : null;
                if (testing) analyzeShift();
                if (n % 2 == 0) {
                    b = obd.pid("0105", "4105", 1);
                    cool = b != null ? b[0] - 40 : null;
                    b = obd.pid("0104", "4104", 1);
                    load = b != null ? Math.round(b[0] * 100f / 255f) : null;
                    b = obd.pid("0110", "4110", 2);
                    maf = b != null ? (b[0] * 256 + b[1]) / 100.0 : null;
                    if (testing) {
                        b = obd.pid("014C", "414C", 1);
                        thrCmd = b != null ? Math.round(b[0] * 100f / 255f) : null;
                        b = obd.pid("0145", "4145", 1);
                        thrAct = b != null ? Math.round(b[0] * 100f / 255f) : null;
                        analyzeThrottle();
                    }
                }
                track();
                if (n % 4 == 0) {
                    b = obd.pid("0106", "4106", 1);
                    stft = b != null ? (b[0] - 128) * 100.0 / 128 : null;
                    b = obd.pid("0107", "4107", 1);
                    ltft = b != null ? (b[0] - 128) * 100.0 / 128 : null;
                    b = obd.pid("0108", "4108", 1);
                    stft2 = b != null ? (b[0] - 128) * 100.0 / 128 : null;
                    b = obd.pid("0109", "4109", 1);
                    ltft2 = b != null ? (b[0] - 128) * 100.0 / 128 : null;
                    b = obd.pid("010F", "410F", 1);
                    iat = b != null ? b[0] - 40 : null;
                    volt = obd.voltage();
                    if (transSupported) {
                        // أمر فورد الخاص لحرارة زيت القير: نجرب كمبيوتر المحرك (7E0) وكمبيوتر القير (7E1)
                        if (transHeader == null) {
                            b = obd.pid("221E1C", "621E1C", 2);
                            if (b != null) {
                                transHeader = "7E0";
                            } else {
                                obd.header("7E1");
                                b = obd.pid("221E1C", "621E1C", 2);
                                obd.header("7E0");
                                if (b != null) transHeader = "7E1";
                            }
                            if (b == null && ++transTries >= 3) transSupported = false;
                        } else if (transHeader.equals("7E0")) {
                            b = obd.pid("221E1C", "621E1C", 2);
                        } else {
                            obd.header("7E1");
                            b = obd.pid("221E1C", "621E1C", 2);
                            obd.header("7E0");
                        }
                        trans = b != null ? Math.round((b[0] * 256 + b[1]) / 16f) : null;
                    }
                }
                if (testing) {
                    record();
                    if (SystemClock.elapsedRealtime() - lastDtcCheck > 60000) readCodes(false);
                }
                n++;
                if (n % 2 == 0 || !testing) runOnUiThread(this::refresh);
                Obd.sleep(testing ? 20 : 150);
            } catch (Exception e) {
                if (stop) break;
                runOnUiThread(() -> {
                    Toast.makeText(this, "انقطع الاتصال بالمحوّل", Toast.LENGTH_LONG).show();
                    beep(ToneGenerator.TONE_CDMA_ABBR_ALERT, 600);
                    disconnect();
                });
                break;
            }
        }
    }

    private void record() {
        long now = SystemClock.elapsedRealtime();
        long minutes = (now - testStart) / 60000;
        if (cool != null) {
            maxCool = Math.max(maxCool, cool);
            if (minutes >= 10 && coolAfter10Min == Integer.MIN_VALUE) coolAfter10Min = cool;
            if (cool >= 106 && now - lastWarnCool > 60000) {
                lastWarnCool = now;
                warn("حرارة الماء عالية: " + cool + "°");
            }
        }
        if (trans != null) {
            maxTrans = Math.max(maxTrans, trans);
            if (trans >= 115 && now - lastWarnTrans > 60000) {
                lastWarnTrans = now;
                warn("حرارة القير عالية: " + trans + "°");
            }
        }
        if (rpm != null) maxRpm = Math.max(maxRpm, rpm);
        if (stft != null && ltft != null && rpm != null && rpm > 500) {
            sumTrim += stft + ltft;
            nTrim++;
        }
        if (stft2 != null && ltft2 != null && rpm != null && rpm > 500) {
            sumTrim2 += stft2 + ltft2;
            nTrim2++;
        }
        if (cool != null && cool >= 80 && speed != null && speed > 20) {
            warmCoolSum += cool;
            warmCoolN++;
        }
        if (volt != null && rpm != null && rpm > 500 && speed != null) {
            minRunV = Math.min(minRunV, volt);
            if (speed == 0 && rpm < 1000) {
                idleVSum += volt;
                idleVN++;
            } else if (rpm > 1500) {
                cruiseVSum += volt;
                cruiseVN++;
            }
        }
        if (volt != null && rpm != null && rpm > 500) {
            sumVolt += volt;
            nVolt++;
            if (volt < 12.8 && now - lastWarnVolt > 120000) {
                lastWarnVolt = now;
                warn("جهد الدينمو منخفض: " + String.format(Locale.US, "%.1f", volt) + " فولت");
            }
        }
        if (speed != null && speed == 0 && rpm != null && rpm > 400 && rpm < 1200) {
            idleSum += rpm;
            idleSq += (double) rpm * rpm;
            idleN++;
        }
        if (speed != null) {
            if (lastSpeedT > 0) distanceKm += speed * ((now - lastSpeedT) / 3600000.0);
            lastSpeedT = now;
        }
        analyzeFan(now);
        // حارس المضخة: وقت التسخين وتذبذب الحرارة وأنت ماشي
        if (cool != null) {
            if (warmStartT == 0 && cool < 45) warmStartT = now;
            if (warmStartT > 0 && warmMin < 0 && cool >= 80) warmMin = (now - warmStartT) / 60000.0;
            if (speed != null && speed > 60 && cool >= 85 && (now - testStart) > 600000) {
                cruiseCoolSum += cool;
                cruiseCoolSq += (double) cool * cool;
                cruiseCoolN++;
            }
        }
        if (now - lastSeriesT >= 3000) {
            lastSeriesT = now;
            JSONArray r = new JSONArray();
            try {
                r.put(Math.round((now - testStart) / 600.0) / 100.0);
                r.put(cool != null ? (Object) cool : JSONObject.NULL);
                r.put(trans != null ? (Object) trans : JSONObject.NULL);
                r.put(speed != null ? (Object) speed : JSONObject.NULL);
            } catch (Exception ignored) {
            }
            if (series.length() < 3000) series.put(r);
        }
    }

    // ───────────── الثروتل ─────────────

    /** يقارن فتحة الثروتل المطلوبة من الكمبيوتر بالفعلية */
    private void analyzeThrottle() {
        Integer c = thrCmd, a = thrAct;
        if (c == null || a == null) return;
        long now = SystemClock.elapsedRealtime();
        // سرعة الاستجابة: لما الطلب يقفز ١٠٪ أو أكثر
        if (prevThrCmd != null && Math.abs(c - prevThrCmd) >= 10 && thrJumpT == 0) {
            thrJumpT = now;
            thrJumpFrom = a;
            thrJumpDir = c > prevThrCmd ? 1 : -1;
            thrMoves++;
        } else if (thrJumpT > 0) {
            if ((a - thrJumpFrom) * thrJumpDir >= 5) {
                thrLagSum += (now - thrJumpT) / 1000.0;
                thrLagN++;
                thrJumpT = 0;
            } else if (now - thrJumpT > 2000) {
                thrLagSum += 2.0;
                thrLagN++;
                thrJumpT = 0;
            }
        }
        // الفرق وهو ثابت: نتعلم الفرق الطبيعي ونراقب الشذوذ
        boolean stable = prevThrCmd != null && Math.abs(c - prevThrCmd) <= 2;
        prevThrCmd = c;
        if (!stable) {
            thrBadRun = 0;
            return;
        }
        double err = a - c;
        if (thrN < 40) {
            thrOff = (thrOff * thrN + err) / (thrN + 1);
            thrN++;
            return;
        }
        if (Math.abs(err - thrOff) > 15) {
            if (++thrBadRun == 3) {
                thrBad++;
                if (bb != null) bb.trigger("الثروتل ما تبع طلب الكمبيوتر (مطلوب " + c + "٪، فعلي " + a + "٪)", now / 1000f);
            }
        } else {
            thrBadRun = 0;
            thrOff = thrOff * 0.98 + err * 0.02;
            thrN++;
        }
    }

    // ───────────── البنزين والعداد و٠-١٠٠ والصندوق الأسود ─────────────

    private void track() {
        long now = SystemClock.elapsedRealtime();
        double dt = lastTrackT > 0 ? Math.min(2.0, (now - lastTrackT) / 1000.0) : 0;
        lastTrackT = now;
        Integer sp = speed, r = rpm;
        if (sp != null) odoAdd += sp * dt / 3600.0;
        if (testing && maf != null && r != null && r > 400) fuelL += maf * dt / (14.7 * 745.0);
        if (now - lastOdoSave > 30000 && odoAdd > 0) {
            lastOdoSave = now;
            float base = prefs.getFloat("odo", -1);
            if (base >= 0) prefs.edit().putFloat("odo", (float) (base + odoAdd)).apply();
            odoAdd = 0;
        }
        // ٠ إلى ١٠٠
        if (sp != null) {
            if (sp == 0) {
                accArmed = true;
                accStart = 0;
                accMaxSpeed = 0;
            } else if (accArmed) {
                if (accStart == 0) accStart = now - 100;
                accMaxSpeed = Math.max(accMaxSpeed, sp);
                if (sp >= 100) {
                    double t = (now - accStart) / 1000.0;
                    accArmed = false;
                    float best = prefs.getFloat("acc_best", 0);
                    SharedPreferences.Editor e = prefs.edit().putFloat("acc_last", (float) t).putLong("acc_time", System.currentTimeMillis());
                    if (best == 0 || t < best) e.putFloat("acc_best", (float) t);
                    e.apply();
                    say(String.format(Locale.US, "صفر لمية في %.1f ثانية", t));
                } else if (sp < accMaxSpeed - 5 || now - accStart > 30000) {
                    accArmed = false;
                }
            }
        }
        // الصندوق الأسود: ٥ صفوف في الثانية
        if (now - lastBbT >= 200 && bb != null) {
            lastBbT = now;
            bb.add(new float[]{now / 1000f, f(sp), f(r), f(cool), f(trans), f(load), f(volt),
                    stft != null && ltft != null ? (float) (stft + ltft) : Float.NaN,
                    stft2 != null && ltft2 != null ? (float) (stft2 + ltft2) : Float.NaN,
                    f(thrCmd), f(thrAct), maf != null ? maf.floatValue() : Float.NaN});
        }
    }

    private static float f(Integer v) {
        return v != null ? v : Float.NaN;
    }

    private static float f(Double v) {
        return v != null ? v.floatValue() : Float.NaN;
    }

    /** المراوح: وهي واقفة والمحرك حار، الحرارة لازم تستقر. لو ظلت ترتفع = المروحة ضعيفة */
    private void analyzeFan(long now) {
        if (cool == null || speed == null) return;
        boolean stopped = speed <= 3 && rpm != null && rpm > 400;
        if (stopped && cool >= 88) {
            if (idleStartCool == null) {
                idleStartCool = cool;
                idleStartT = now;
            }
            maxIdleCool = Math.max(maxIdleCool, cool);
        } else if (idleStartCool != null) {
            long dur = now - idleStartT;
            if (dur >= 45000) {
                idleEpisodes++;
                // وقفة أكثر من ٤٥ ثانية: ارتفاع ٥ درجات أو أكثر، أو تعدّي ١٠٤ = المروحة ما لحقت
                if (maxIdleCool - idleStartCool >= 5 || maxIdleCool >= 104) badIdleEpisodes++;
            }
            idleStartCool = null;
        }
    }

    /** سلاسة القير: نسبة الدوران/السرعة تحدد النقلة، وتغيّرها = تبديل */
    private void analyzeShift() {
        if (rpm == null || speed == null) return;
        long now = SystemClock.elapsedRealtime();
        double ratio = speed > 12 ? rpm / (double) speed : -1;
        synchronized (samples) {
            samples.addLast(new double[]{now, rpm, speed, ratio});
            while (!samples.isEmpty() && now - samples.peekFirst()[0] > 5000) samples.pollFirst();
        }
        if (ratio < 0) {
            stableRatio = -1;
            return;
        }
        // النسبة مستقرة إذا آخر ٠٫٧ ثانية كلها ضمن ٦٪
        double mn = Double.MAX_VALUE, mx = 0;
        int cnt = 0;
        synchronized (samples) {
            for (double[] sm : samples) {
                if (now - sm[0] > 700 || sm[3] < 0) continue;
                mn = Math.min(mn, sm[3]);
                mx = Math.max(mx, sm[3]);
                cnt++;
            }
        }
        if (cnt < 2 || mx > mn * 1.06) return;
        double cur = (mn + mx) / 2;
        if (stableRatio < 0) {
            stableRatio = cur;
            stableSince = now;
            return;
        }
        if (cur < stableRatio * 0.82 || cur > stableRatio * 1.22) {
            boolean up = cur < stableRatio;
            // بداية التبديل = آخر عيّنة كانت قريبة من النسبة القديمة
            long tStart = stableSince;
            double peakRatio = 0;
            synchronized (samples) {
                for (double[] sm : samples) {
                    if (sm[3] < 0) continue;
                    if (Math.abs(sm[3] - stableRatio) <= stableRatio * 0.06) tStart = (long) sm[0];
                    if (sm[0] >= tStart) peakRatio = Math.max(peakRatio, sm[3]);
                }
            }
            if (up) {
                upshifts++;
                double secs = Math.max(0.1, (now - 700 - tStart) / 1000.0);
                shiftTimeSum += secs;
                // تفليت: الدوران ارتفع فوق النسبة القديمة ٨٪ وقت التبديل
                if (peakRatio > stableRatio * 1.08) {
                    flares++;
                    if (now - lastFlareSay > 60000) {
                        lastFlareSay = now;
                        say("انتبه، القير فلّت في التبديل");
                    }
                }
                // رجّة: قفزة قوية في حساس الحركة وقت التبديل
                double maxJerk = 0;
                synchronized (jolts) {
                    for (double[] j : jolts) if (j[0] >= tStart - 300) maxJerk = Math.max(maxJerk, j[1]);
                }
                if (maxJerk > 18) harsh++;
            } else {
                downshifts++;
            }
            stableRatio = cur;
            stableSince = now;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        double mag = Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
        long now = SystemClock.elapsedRealtime();
        if (lastAccMag >= 0 && now > lastAccT) {
            double jerk = Math.abs(mag - lastAccMag) / ((now - lastAccT) / 1000.0);
            synchronized (jolts) {
                jolts.addLast(new double[]{now, jerk});
                while (!jolts.isEmpty() && now - jolts.peekFirst()[0] > 5000) jolts.pollFirst();
            }
        }
        lastAccMag = mag;
        lastAccT = now;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /** [الدرجة، النص] لسلاسة القير */
    private Object[] gearScore() {
        StringBuilder r = new StringBuilder();
        if (upshifts < 3) return new Object[]{-1, "امشِ مشوار فيه تسارع من وقوف عشان يلقط ٣ تبديلات على الأقل"};
        int s = 100;
        double avg = shiftTimeSum / upshifts;
        r.append("التبديلات: ").append(upshifts).append(" لفوق، ").append(downshifts).append(" لتحت\n");
        if (avg > 1.6) {
            s -= 15;
            r.append("⚠ التبديل بطيء (متوسط ").append(String.format(Locale.US, "%.1f", avg)).append(" ث): ممكن زيت القير ناقص أو قديم\n");
        } else {
            r.append("✓ سرعة التبديل طبيعية (").append(String.format(Locale.US, "%.1f", avg)).append(" ث تقريباً)\n");
        }
        double fr = flares / (double) upshifts;
        if (fr > 0.2) {
            s -= 25;
            r.append("✗ تفليت في ").append(flares).append(" تبديلات: انزلاق — افحص زيت القير\n");
        } else if (flares > 0) {
            s -= 8;
            r.append("⚠ تفليت خفيف مرة أو مرتين\n");
        } else {
            r.append("✓ ما فيه تفليت (التعشيق ماسك)\n");
        }
        if (sm == null || sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION) == null) {
            r.append("– الرجّة: الجهاز ما فيه حساس حركة\n");
        } else {
            double hr = harsh / (double) upshifts;
            if (hr > 0.25) {
                s -= 15;
                r.append("⚠ رجّة قوية في ").append(harsh).append(" تبديلات\n");
            } else {
                r.append("✓ التبديل ناعم بدون رجّة\n");
            }
        }
        if (maxTrans != Integer.MIN_VALUE && maxTrans >= 115) s -= 10;
        return new Object[]{Math.max(0, s), r.toString().trim()};
    }

    private String fanText() {
        if (idleEpisodes == 0) return "يحتاج وقفة دقيقة تقريباً والمحرك حار (إشارة أو زحمة)";
        if (badIdleEpisodes == 0)
            return "✓ المراوح تبرّد زين — الحرارة استقرت وأنت واقف (أعلى " + maxIdleCool + "°)";
        if (badIdleEpisodes * 2 >= idleEpisodes)
            return "✗ المراوح ضعيفة: الحرارة ترتفع وأنت واقف (وصلت " + maxIdleCool + "°) — افحص المروحة وريليهها";
        return "⚠ مرة ارتفعت الحرارة وأنت واقف (" + maxIdleCool + "°) — راقبها";
    }

    private void warn(String msg) {
        runOnUiThread(() -> {
            beep(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600);
            Toast.makeText(this, "⚠ " + msg, Toast.LENGTH_LONG).show();
        });
        say("انتبه. " + msg);
        if (bb != null) bb.trigger(msg, SystemClock.elapsedRealtime() / 1000f);
    }

    private void beep(int t, int ms) {
        try {
            if (tone != null) tone.startTone(t, ms);
        } catch (Exception ignored) {
        }
    }

    private void readCodes(boolean manual) {
        lastDtcCheck = SystemClock.elapsedRealtime();
        try {
            List<String> s = obd.dtcs("03");
            List<String> p = obd.dtcs("07");
            List<String> fresh = new ArrayList<>();
            for (String c : s) if (!seen.contains(c)) fresh.add(c);
            for (String c : p) if (!seen.contains(c)) fresh.add(c);
            stored.clear();
            stored.addAll(s);
            pending.clear();
            pending.addAll(p);
            seen.addAll(s);
            seen.addAll(p);
            // أول فحص في الاختبار = نقطة البداية، بعده أي كود جديد ينبّه
            if (!fresh.isEmpty() && testing && baselineDone) {
                boolean tank = false;
                for (String c : fresh) if (Dtc.isFuelTank(c)) tank = true;
                warn(tank ? "فتحة البنزين أو الخزان فيها مشكلة. تأكد إن الغطا مسكّر زين (" + TextUtils.join("، ", fresh) + ")"
                        : "عطل جديد: " + TextUtils.join("، ", fresh));
            }
            if (testing) baselineDone = true;
            if (!stored.isEmpty() && (!freezeDone || manual)) readFreeze();
            if (stored.isEmpty()) freezeText = "";
            runOnUiThread(this::refreshCodes);
        } catch (Exception e) {
            runOnUiThread(() -> tvCodes.setText("تعذّرت قراءة الأعطال"));
        }
    }

    private void checkCodesNow() {
        if (!connected) {
            Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
            return;
        }
        tvCodes.setText("جاري الفحص...");
        new Thread(() -> readCodes(true)).start();
    }

    private void confirmClear() {
        if (!connected) {
            Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("مسح الأعطال؟")
                .setMessage("يمسح الأكواد ويطفي لمبة فحص المحرك. إذا العطل موجود فعلاً بيرجع. خلّ المحرك طافي والإشعال شغال.")
                .setPositiveButton("امسح", (d, w) -> new Thread(() -> {
                    boolean ok = false;
                    try {
                        ok = obd.clearCodes();
                    } catch (Exception ignored) {
                    }
                    final boolean f = ok;
                    runOnUiThread(() -> Toast.makeText(this, f ? "تم مسح الأعطال" : "ما تم المسح", Toast.LENGTH_LONG).show());
                    if (f) {
                        seen.clear();
                        readCodes(true);
                    }
                }).start())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    // ───────────── الاختبار والتقييم ─────────────

    private void onTestClick() {
        if (!connected) {
            Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!testing) {
            testStart = SystemClock.elapsedRealtime();
            maxCool = Integer.MIN_VALUE;
            maxTrans = Integer.MIN_VALUE;
            maxRpm = 0;
            coolAfter10Min = Integer.MIN_VALUE;
            sumTrim = sumVolt = idleSum = idleSq = distanceKm = 0;
            nTrim = nVolt = idleN = 0;
            lastSpeedT = 0;
            lastDtcCheck = 0;
            seen.clear();
            baselineDone = false;
            samples.clear();
            jolts.clear();
            stableRatio = -1;
            upshifts = downshifts = flares = harsh = 0;
            shiftTimeSum = 0;
            idleSamples = idleRising = idleEpisodes = badIdleEpisodes = 0;
            maxIdleCool = Integer.MIN_VALUE;
            idleStartCool = null;
            sumTrim2 = warmCoolSum = idleVSum = cruiseVSum = 0;
            nTrim2 = warmCoolN = idleVN = cruiseVN = 0;
            minRunV = 99;
            printResult = "";
            needMisfire = true;
            thrOff = 0;
            thrN = thrBadRun = thrBad = thrMoves = thrLagN = 0;
            thrLagSum = 0;
            prevThrCmd = null;
            thrJumpT = 0;
            warmStartT = 0;
            warmMin = -1;
            cruiseCoolSum = cruiseCoolSq = 0;
            cruiseCoolN = 0;
            fuelL = 0;
            series = new JSONArray();
            lastSeriesT = 0;
            testing = true;
            say("بدأ الاختبار. سُق عادي وأنا أراقب");
            btnTest.setText("إنهاء الاختبار");
            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            if (sm != null) {
                Sensor acc = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
                if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME);
            }
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            beep(ToneGenerator.TONE_PROP_ACK, 300);
        } else {
            testing = false;
            btnTest.setText("ابدأ الاختبار");
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (sm != null) sm.unregisterListener(this);
            needMisfire = true;
            needDiag = true;
            saveTrip();
            saveHistory();
            refresh();
            Object[] fs = score();
            say("انتهى الاختبار. تقييم المكينة " + fs[0] + " من مية");
            new AlertDialog.Builder(this)
                    .setTitle("نتيجة الاختبار")
                    .setMessage(report())
                    .setPositiveButton("تم", null)
                    .setNeutralButton("مشاركة", (d, w) -> shareReport())
                    .show();
        }
    }

    // ───────────── تقطيع البساتم ─────────────

    private void readMisfire() {
        needMisfire = false;
        lastMisfire = SystemClock.elapsedRealtime();
        if (!misSupported) return;
        int got = 0;
        for (int c = 0; c < 6; c++) {
            try {
                mis[c] = obd.misfire(c + 1);
            } catch (Exception e) {
                mis[c] = null;
            }
            if (mis[c] != null) got++;
        }
        if (got == 0 && ++misFail >= 2) misSupported = false;
    }

    /** {رقم البستم، العدد} لأكثر بستم يقطّع */
    private int[] misfireWorst() {
        int best = -1, cnt = -1;
        for (int c = 0; c < 6; c++) {
            if (mis[c] == null) continue;
            int v = Math.max(mis[c][0], mis[c][1]);
            if (v > cnt) {
                cnt = v;
                best = c + 1;
            }
        }
        return best < 0 ? null : new int[]{best, cnt};
    }

    private String mechText() {
        StringBuilder r = new StringBuilder();
        // التقطيع
        if (!misSupported) {
            r.append("– التقطيع: السيارة ما ردّت على أمر Mode 06\n");
        } else if (misfireWorst() == null) {
            r.append("– التقطيع: يقرأ بعد الاتصال\n");
        } else {
            r.append("تقطيع البساتم (هالتشغيلة / المعدّل):\n");
            int bad = 0;
            for (int c = 0; c < 6; c++) {
                if (mis[c] == null) continue;
                int v = Math.max(mis[c][0], mis[c][1]);
                String m = v >= 40 ? "✗" : v >= 10 ? "⚠" : "✓";
                if (v >= 10) bad++;
                r.append(m).append(" بستم ").append(c + 1).append(": ").append(mis[c][1]).append(" / ").append(mis[c][0]);
                r.append(c % 2 == 1 ? "\n" : "     ");
            }
            if (bad == 1) {
                int[] w = misfireWorst();
                r.append("← البستم ").append(w[0]).append(" لحاله: غالباً الكويل أو البوجي حقه. بدّل كويله مع اللي جنبه، إذا انتقل التقطيع فالعيب في الكويل\n");
            } else if (bad > 1) {
                r.append("← أكثر من بستم: بواجي قديمة، أو ضعف بنزين، أو تسريب هوا\n");
            } else {
                r.append("← ما فيه تقطيع يذكر\n");
            }
        }
        // الخليط لكل جهة
        if (nTrim > 20) {
            double b1 = sumTrim / nTrim;
            double b2 = nTrim2 > 20 ? sumTrim2 / nTrim2 : Double.NaN;
            r.append(String.format(Locale.US, "\nالخليط: ج١ (بساتم ١-٣) %+.0f%%", b1));
            if (!Double.isNaN(b2)) r.append(String.format(Locale.US, "  •  ج٢ (بساتم ٤-٦) %+.0f%%", b2));
            r.append("\n");
            if (Double.isNaN(b2)) {
                if (Math.abs(b1) <= 10) r.append("✓ الخليط سليم\n");
            } else if (b1 > 10 && b2 > 10) {
                r.append("⚠ الجهتين فقير: حساس الهوا (MAF) متّسخ، أو ضعف ضغط البنزين (الطرمبة أو الفلتر)\n");
            } else if (b1 < -10 && b2 < -10) {
                r.append("⚠ الجهتين غني: حساس الهوا يقرأ غلط، أو ضغط بنزين زايد\n");
            } else if (b1 > 10 || b2 > 10) {
                r.append("⚠ الجهة ").append(b1 > 10 ? "١" : "٢").append(" فقيرة لحالها: تسريب هوا (جوان المنيفولد أو لي فاكيوم) أو بخاخ ضعيف في هذي الجهة\n");
            } else if (b1 < -10 || b2 < -10) {
                r.append("⚠ الجهة ").append(b1 < -10 ? "١" : "٢").append(" غنية لحالها: بخاخ يهرّب أو حساس أكسجين هذي الجهة\n");
            } else {
                r.append("✓ الخليط سليم في الجهتين\n");
            }
        } else {
            r.append("\nالخليط لكل جهة: يطلع بعد دقيقتين سواقة في الاختبار\n");
        }
        return r.toString().trim();
    }

    // ───────────── الـABS ─────────────

    private void readAbs() {
        if (!connected) {
            Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
            return;
        }
        tvAbs.setText("أكلّم كمبيوتر الـABS...");
        tvAbs.setTextColor(SUB);
        new Thread(() -> {
            paused = true;
            Obd.sleep(400);
            String res;
            try {
                List<String[]> l = obd.absCodes();
                if (l == null) {
                    res = "– كمبيوتر الـABS ما ردّ على المحوّل. أكواده تنقرى بـFORScan";
                } else if (l.isEmpty()) {
                    res = "✓ الفرامل ABS والثبات: ما فيه أعطال";
                } else {
                    StringBuilder sb = new StringBuilder("✗ أعطال الفرامل ABS والثبات:\n");
                    for (String[] c : l) {
                        String[] d = Dtc.describe(c[0]);
                        sb.append(c[1].equals("s") ? "● " : "○ ").append(c[0]).append(c[1].equals("s") ? "  " : " (معلّق)  ")
                                .append(d[0]).append("\n   الأسباب: ").append(d[1]).append("\n");
                    }
                    sb.append("لمبة ABS أو الثبات في الطبلون غالباً شابّة معها");
                    res = sb.toString();
                    say("فيه " + l.size() + " عطل في الفرامل أو الثبات");
                }
            } catch (Exception e) {
                res = "تعذّرت قراءة الـABS";
            }
            paused = false;
            absText = res;
            final String fr = res;
            runOnUiThread(() -> {
                tvAbs.setText(fr);
                tvAbs.setTextColor(fr.startsWith("✗") ? RED : fr.startsWith("✓") ? GREEN : SUB);
            });
        }).start();
    }

    // ───────────── حارس إيدج ─────────────

    private int pumpLowCount() {
        int c = 0;
        long now = System.currentTimeMillis();
        for (String t : prefs.getString("pump_low", "").split(",")) {
            try {
                if (!t.isEmpty() && now - Long.parseLong(t) < 60L * 86400000) c++;
            } catch (NumberFormatException ignored) {
            }
        }
        return c;
    }

    private String edgeText() {
        StringBuilder r = new StringBuilder();
        // مضخة الماء الداخلية
        r.append("💧 مضخة الماء الداخلية (أخطر عيب في محرك 3.5):\n");
        String last = prefs.getString("pump_last", "");
        long lastT = prefs.getLong("pump_time", 0);
        long days = lastT > 0 ? (System.currentTimeMillis() - lastT) / 86400000 : -1;
        if (last.equals("milky")) {
            r.append("✗ سجّلت رغوة أو لون حليبي تحت غطا الزيت: علامة دخول ماء للزيت. لا تسوق مسافات، وودّها فني يفحص ضغط دورة الماء والزيت\n");
        } else if (pumpLowCount() >= 2) {
            r.append("⚠ الماء نقص ").append(pumpLowCount()).append(" مرات خلال شهرين. إذا ما فيه تسريب تحت السيارة، اشتبه بالمضخة الداخلية وافحص الزيت\n");
        } else if (last.equals("low")) {
            r.append("⚠ آخر فحص: الماء ناقص. كمّله وراقبه\n");
        } else if (last.equals("ok")) {
            r.append("✓ آخر فحص للماء والزيت طبيعي\n");
        }
        if (days < 0) r.append("⏰ ما سجّلت فحص للحين: افتح الكبوت والمكينة باردة، وشف مستوى الماء وتحت غطا الزيت\n");
        else if (days >= 7) r.append("⏰ صار لك ").append(days).append(" يوم ما فحصت الماء والزيت\n");
        if (cruiseCoolN > 60) {
            double m = cruiseCoolSum / cruiseCoolN;
            double sd = Math.sqrt(Math.max(0, cruiseCoolSq / cruiseCoolN - m * m));
            if (sd > 3) r.append(String.format(Locale.US, "⚠ الحرارة تتذبذب وأنت ماشي (±%.0f°): هوا في الدورة، ثرموستات، أو بداية مشكلة مضخة\n", sd));
            else r.append(String.format(Locale.US, "✓ الحرارة ثابتة وأنت ماشي (±%.0f°)\n", sd));
        }
        if (warmMin > 0) {
            r.append(String.format(Locale.US, warmMin > 15 ? "⚠ المكينة أخذت %.0f دقيقة تسخن: الثرموستات عالق مفتوح\n" : "✓ وقت التسخين طبيعي (%.0f دقايق)\n", warmMin));
        }
        // الثروتل
        r.append("\n⚙️ بوابة الهوا (الثروتل) — سبب \"تطفي وهي ماشية\":\n");
        if (thrN < 40) {
            r.append(testing ? "– يتعلّم... امشِ شوي\n" : "– يتفحص أثناء اختبار القيادة\n");
        } else {
            double lag = thrLagN > 0 ? thrLagSum / thrLagN : 0;
            if (thrBad >= 2) r.append("✗ ما تتبع طلب الكمبيوتر ").append(thrBad).append(" مرات: نظّف الثروتل أو افحصه قبل ما يطفي فيك\n");
            else if (thrBad == 1) r.append("⚠ مرة وحدة ما تبعت الطلب — راقبها\n");
            else r.append("✓ تتبع طلب الكمبيوتر\n");
            if (thrLagN >= 5) r.append(String.format(Locale.US, lag > 0.8 ? "⚠ استجابتها بطيئة (%.1f ث): كربون أو مشكلة بداية\n" : "✓ استجابتها سريعة (%.1f ث)\n", lag));
        }
        // القير والـ PTU
        r.append("\n🔩 القير والـ PTU ومبرّد القير:\n");
        if (maxTrans != Integer.MIN_VALUE) {
            if (maxTrans >= 110) r.append("⚠ حرارة القير وصلت ").append(maxTrans).append("°: الحرارة العالية تخرب زيت القير والـPTU (لو دفع رباعي). افحص مبرّد القير ومستوى الزيت\n");
            else r.append("✓ حرارة القير تحت الحمل طبيعية (أعلى ").append(maxTrans).append("°)\n");
        } else if (!transSupported) {
            r.append("– حرارة القير ما تنقرى\n");
        } else {
            r.append("– يتفحص أثناء الاختبار\n");
        }
        r.append("نصيحة: شيّك تحت السيارة يمين قدام على تسريب زيت بني (PTU) أو أحمر (القير)");
        return r.toString().trim();
    }

    private void pumpCheckDialog() {
        String[] opts = {"✓ كله طبيعي (الماء على العلامة والغطا نظيف)", "⚠ الماء نازل عن العلامة", "✗ رغوة أو لون حليبي تحت غطا الزيت"};
        new AlertDialog.Builder(this).setTitle("فحص الماء والزيت (والمكينة باردة)")
                .setItems(opts, (d, w) -> {
                    long now = System.currentTimeMillis();
                    SharedPreferences.Editor e = prefs.edit().putLong("pump_time", now);
                    if (w == 0) e.putString("pump_last", "ok");
                    if (w == 1) {
                        e.putString("pump_last", "low");
                        e.putString("pump_low", prefs.getString("pump_low", "") + now + ",");
                    }
                    if (w == 2) e.putString("pump_last", "milky");
                    e.apply();
                    if (w == 2) say("انتبه. هذي علامة دخول ماء للزيت. لا تسوق مسافات وودّها فني");
                    refreshExtra();
                }).setNegativeButton("إلغاء", null).show();
    }

    // ───────────── فحوصات الكمبيوتر ─────────────

    private void readDiag() {
        needDiag = false;
        StringBuilder r = new StringBuilder();
        try {
            int[] b = obd.pid("0101", "4101", 4);
            if (b != null) {
                boolean mil = (b[0] & 0x80) != 0;
                r.append(mil ? "✗ لمبة المكينة شغالة" : "✓ لمبة المكينة طافية").append("\n");
                String[] base = {"التقطيع", "نظام البنزين", "الحساسات والقطع"};
                String[] spark = {"الدبة (الكتلايزر)", "تسخين الدبة", "نظام أبخرة البنزين (EVAP)", "الهوا الثانوي", "", "حساسات الأكسجين", "سخان حساسات الأكسجين", "EGR / VVT"};
                List<String> done = new ArrayList<>(), not = new ArrayList<>();
                for (int i = 0; i < 3; i++) {
                    if ((b[1] & (1 << i)) == 0) continue;
                    if ((b[1] & (1 << (i + 4))) != 0) not.add(base[i]);
                    else done.add(base[i]);
                }
                for (int i = 0; i < 8; i++) {
                    if (spark[i].isEmpty() || (b[2] & (1 << i)) == 0) continue;
                    if ((b[3] & (1 << i)) != 0) not.add(spark[i]);
                    else done.add(spark[i]);
                }
                if (not.isEmpty()) r.append("✓ كل أنظمة الفحص الذاتي مكتملة (").append(done.size()).append(")\n");
                else {
                    r.append("⏳ ما اكتمل: ").append(TextUtils.join("، ", not)).append("\n");
                    r.append("   (طبيعي بعد مسح الأكواد أو فصل البطارية. يكتمل بعد كم مشوار فيه طريق سريع ووقفات. وإذا ما اكتمل أبداً فيه عيب مخفي)\n");
                }
            }
        } catch (Exception ignored) {
        }
        readyText = r.toString().trim();

        StringBuilder m = new StringBuilder();
        int[][] mids = {{0x21, 0}, {0x22, 0}, {0x01, 1}, {0x02, 1}, {0x05, 1}, {0x06, 1}, {0x39, 2}, {0x3A, 2}, {0x3B, 2}, {0x3C, 2}};
        String[] names = {"الدبة جهة ١", "الدبة جهة ٢", "حساس أكسجين ج١ قبل الدبة", "حساس أكسجين ج١ بعد الدبة",
                "حساس أكسجين ج٢ قبل الدبة", "حساس أكسجين ج٢ بعد الدبة", "تسريب أبخرة كبير (الغطا)", "تسريب أبخرة 0.090", "تسريب أبخرة 0.040", "تسريب أبخرة صغير 0.020"};
        int got = 0;
        for (int i = 0; i < mids.length; i++) {
            try {
                List<int[]> t = obd.monitor(mids[i][0]);
                if (t == null) continue;
                got++;
                boolean fail = false, near = false;
                for (int[] x : t) {
                    if (x[1] < x[2] || x[1] > x[3]) fail = true;
                    else if (x[3] > x[2] && x[3] - x[2] < 60000) {
                        double pos = (x[1] - x[2]) / (double) (x[3] - x[2]);
                        if (x[2] > 0 && pos < 0.1 || x[3] < 65535 && pos > 0.9) near = true;
                    }
                }
                m.append(fail ? "✗ " : near ? "⚠ " : "✓ ").append(names[i]).append(fail ? ": ما نجح" : near ? ": قريب من الحد" : ": سليم").append("\n");
            } catch (Exception ignored) {
            }
        }
        monText = got == 0 ? "– السيارة ما ردّت على نتائج الفحوصات" : m.toString().trim();
        runOnUiThread(this::refreshExtra);
    }

    private void readFreeze() {
        freezeDone = true;
        StringBuilder r = new StringBuilder();
        try {
            String raw = Obd.clean(obd.cmd("020200", 1500));
            int i = raw.indexOf("420200");
            if (i >= 0 && raw.length() >= i + 10) {
                String c = Obd.decode(raw.substring(i + 6, i + 10));
                if (c != null) r.append("الكود اللي صوّر: ").append(c).append("\n");
            }
            int[] b;
            if ((b = obd.pid("020D00", "420D00", 1)) != null) r.append("السرعة: ").append(b[0]).append(" كم/س\n");
            if ((b = obd.pid("020C00", "420C00", 2)) != null) r.append("الدوران: ").append((b[0] * 256 + b[1]) / 4).append("\n");
            if ((b = obd.pid("020500", "420500", 1)) != null) r.append("حرارة الماء: ").append(b[0] - 40).append("°\n");
            if ((b = obd.pid("020400", "420400", 1)) != null) r.append("حمل المحرك: ").append(Math.round(b[0] * 100f / 255f)).append("%\n");
            int[] t1 = obd.pid("020600", "420600", 1), t2 = obd.pid("020700", "420700", 1);
            if (t1 != null && t2 != null)
                r.append(String.format(Locale.US, "تصحيح الخليط: %+.0f%%\n", (t1[0] - 128) * 100.0 / 128 + (t2[0] - 128) * 100.0 / 128));
            if ((b = obd.pid("020F00", "420F00", 1)) != null) r.append("حرارة الهوا: ").append(b[0] - 40).append("°\n");
        } catch (Exception ignored) {
        }
        freezeText = r.toString().trim();
    }

    private String diagText() {
        StringBuilder r = new StringBuilder();
        r.append(readyText.isEmpty() ? "– الجاهزية: تنقرى بعد الاتصال" : readyText).append("\n\n");
        r.append(monText.isEmpty() ? "– نتائج الدبة والحساسات: تنقرى بعد الاتصال" : monText);
        return r.toString().trim();
    }

    // ───────────── البنزين والصيانة ─────────────

    private float price() {
        return prefs.getFloat("price", 2.18f);
    }

    private String tripText() {
        StringBuilder r = new StringBuilder();
        if (fuelL > 0.01) {
            r.append(String.format(Locale.US, "هالمشوار: %.2f لتر  •  %.2f ريال", fuelL, fuelL * price()));
            if (distanceKm > 1) r.append(String.format(Locale.US, "\nالاستهلاك: %.1f لتر/100كم  •  %.1f كم/لتر", fuelL * 100 / distanceKm, distanceKm / fuelL));
            r.append("\n");
        } else {
            r.append("البنزين يتحسب أثناء الاختبار (سعر اللتر ").append(String.format(Locale.US, "%.2f", price())).append(" ريال)\n");
        }
        float last = prefs.getFloat("acc_last", 0), best = prefs.getFloat("acc_best", 0);
        if (last > 0) r.append(String.format(Locale.US, "\n🏁 ٠-١٠٠: آخر مرة %.1f ث  •  أفضل %.1f ث", last, best));
        else r.append("\n🏁 ٠-١٠٠: يقيس لحاله لما تسرّع من وقوف لين ١٠٠ (في مكان آمن)");
        return r.toString().trim();
    }

    private static final String[][] MAINT = {
            {"oil", "زيت المكينة", "5000"},
            {"air", "فلتر الهوا", "20000"},
            {"atf", "زيت القير", "60000"},
            {"plugs", "البواجي", "100000"},
            {"coolant", "ماء الردياتير (تبديل)", "100000"}};

    private String maintText() {
        float odo = prefs.getFloat("odo", -1);
        if (odo < 0) return "اضغط \"تحديث العداد والصيانة\" وحط قراءة العداد وآخر تبديل لكل شي";
        double now = odo + odoAdd;
        StringBuilder r = new StringBuilder(String.format(Locale.US, "العداد تقريباً: %,.0f كم\n", now));
        for (String[] it : MAINT) {
            float last = prefs.getFloat("m_" + it[0], -1);
            if (last < 0) continue;
            int iv = prefs.getInt("i_" + it[0], Integer.parseInt(it[2]));
            double left = last + iv - now;
            String mk = left <= 0 ? "✗" : left <= Math.max(500, iv * 0.1) ? "⚠" : "✓";
            r.append(mk).append(" ").append(it[1]).append(": ");
            r.append(left <= 0 ? String.format(Locale.US, "فات موعده بـ %,.0f كم", -left) : String.format(Locale.US, "باقي %,.0f كم", left)).append("\n");
        }
        r.append("(العداد يزيد من مشاويرك والتطبيق متصل — صحّحه كل فترة)");
        return r.toString().trim();
    }

    private void maintDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), dp(8));
        List<EditText> fields = new ArrayList<>();
        String[] labels = new String[MAINT.length + 2];
        labels[0] = "قراءة العداد الحين (كم)";
        for (int i = 0; i < MAINT.length; i++) labels[i + 1] = "آخر " + MAINT[i][1] + " عند كم؟ (كل " + MAINT[i][2] + ")";
        labels[labels.length - 1] = "سعر لتر البنزين (91 = 2.18، 95 = 2.33)";
        for (int i = 0; i < labels.length; i++) {
            TextView t = new TextView(this);
            t.setText(labels[i]);
            l.addView(t);
            EditText e = new EditText(this);
            e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            float v;
            if (i == 0) v = prefs.getFloat("odo", -1) >= 0 ? (float) (prefs.getFloat("odo", 0) + odoAdd) : -1;
            else if (i == labels.length - 1) v = price();
            else v = prefs.getFloat("m_" + MAINT[i - 1][0], -1);
            if (v >= 0) e.setText(i == labels.length - 1 ? String.format(Locale.US, "%.2f", v) : String.valueOf(Math.round(v)));
            l.addView(e);
            fields.add(e);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle("الصيانة").setView(sv)
                .setPositiveButton("حفظ", (d, w) -> {
                    SharedPreferences.Editor e = prefs.edit();
                    for (int i = 0; i < fields.size(); i++) {
                        String s = fields.get(i).getText().toString().trim().replace(',', '.');
                        if (s.isEmpty()) continue;
                        try {
                            float v = Float.parseFloat(s);
                            if (i == 0) {
                                e.putFloat("odo", v);
                                odoAdd = 0;
                            } else if (i == fields.size() - 1) e.putFloat("price", v);
                            else e.putFloat("m_" + MAINT[i - 1][0], v);
                        } catch (NumberFormatException ignored) {
                        }
                    }
                    e.apply();
                    refreshExtra();
                }).setNegativeButton("إلغاء", null).show();
    }

    private void saveHistory() {
        try {
            long sec = (SystemClock.elapsedRealtime() - testStart) / 1000;
            if (sec < 120) return;
            JSONObject t = new JSONObject();
            t.put("date", new SimpleDateFormat("MM/dd HH:mm", Locale.US).format(new Date()));
            t.put("min", sec / 60);
            t.put("km", Math.round(distanceKm * 10) / 10.0);
            t.put("score", score()[0]);
            t.put("gear", gearScore()[0]);
            if (maxCool != Integer.MIN_VALUE) t.put("cool", maxCool);
            if (maxTrans != Integer.MIN_VALUE) t.put("trans", maxTrans);
            if (fuelL > 0.01) {
                t.put("fuel", Math.round(fuelL * 100) / 100.0);
                t.put("cost", Math.round(fuelL * price() * 100) / 100.0);
                if (distanceKm > 1) t.put("l100", Math.round(fuelL * 1000 / distanceKm) / 10.0);
            }
            JSONArray trips = new JSONArray(prefs.getString("trips", "[]"));
            trips.put(t);
            while (trips.length() > 60) trips.remove(0);
            prefs.edit().putString("trips", trips.toString()).putString("series", series.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    // ───────────── الكهرباء ─────────────

    private String elecText() {
        StringBuilder r = new StringBuilder();
        if (prefs.contains("bat_min")) {
            float rest = prefs.getFloat("bat_rest", 0), min = prefs.getFloat("bat_min", 0);
            String when = new SimpleDateFormat("MM/dd HH:mm", Locale.US).format(new Date(prefs.getLong("bat_time", 0)));
            r.append("آخر فحص بطارية (").append(when).append("):\n");
            r.append(batteryVerdict(rest, min, prefs.getFloat("bat_after", 0), prefs.getFloat("bat_prev_rest", 0),
                    prefs.getLong("bat_prev_time", 0), prefs.getLong("bat_time", 0))).append("\n");
        } else {
            r.append("البطارية: اضغط الزر تحت والمكينة طافية\n");
        }
        if (idleVN > 20 || cruiseVN > 20) {
            r.append("\nالدينمو وهو ماشي:\n");
            double iv = idleVN > 20 ? idleVSum / idleVN : Double.NaN;
            double cv = cruiseVN > 20 ? cruiseVSum / cruiseVN : Double.NaN;
            if (!Double.isNaN(iv)) r.append(String.format(Locale.US, "واقف: %.1f فولت", iv));
            if (!Double.isNaN(cv)) r.append(String.format(Locale.US, "%sماشي: %.1f فولت", Double.isNaN(iv) ? "" : "  •  ", cv));
            if (minRunV < 50) r.append(String.format(Locale.US, "  •  أقل قراءة: %.1f", minRunV));
            r.append("\n");
            if (!Double.isNaN(cv) && cv > 15.0) {
                r.append("✗ شحن زايد: منظّم الدينمو — يخرّب البطارية\n");
            } else if (!Double.isNaN(cv) && cv < 13.0) {
                r.append("✗ الدينمو ما يشحن كفاية حتى وهو ماشي — افحصه\n");
            } else if (!Double.isNaN(iv) && iv < 12.9) {
                r.append("⚠ يضعف وهي واقفة: سير الدينمو مرتخي أو الدينمو بدأ يضعف. جرّب: وأنت واقف شغّل المكيف والأنوار وشوف القراءة\n");
            } else {
                r.append("✓ الدينمو يشحن زين حتى تحت الحمل\n");
            }
        }
        return r.toString().trim();
    }

    private String batteryVerdict(float rest, float min, float after, float prevRest, long prevT, long t) {
        StringBuilder r = new StringBuilder();
        r.append(String.format(Locale.US, "وهي طافية: %.2f فولت — ", rest));
        r.append(rest >= 12.6 ? "مشحونة كامل ✓" : rest >= 12.4 ? "طبيعي ✓" : rest >= 12.2 ? "نص شحن ⚠" : "فاضية أو ضعيفة ✗").append("\n");
        if (min > 0) {
            r.append(String.format(Locale.US, "وقت الدقة نزلت لـ: %.1f فولت — ", min));
            r.append(min >= 10.0 ? "✓ البطارية قوية" : min >= 9.6 ? "⚠ بدأت تضعف، جهّز بديلها" : "✗ ضعيفة، بتخرب قريب — بدّلها").append("\n");
        }
        if (after > 0) {
            r.append(String.format(Locale.US, "بعد التشغيل: %.1f فولت — ", after));
            r.append(after >= 13.2 ? "✓ الدينمو بدأ يشحن" : "⚠ الشحن ما بدأ — راقب الدينمو").append("\n");
        }
        if (prevRest > 0 && t - prevT < 72L * 3600000 && prevRest - rest >= 0.3) {
            r.append(String.format(Locale.US, "⚠ نزلت %.1f فولت عن الفحص اللي قبله. إذا السيارة كانت واقفة بينهم = فيه سحب كهرباء (تسريب)\n", prevRest - rest));
        }
        r.append("(أدق قراءة: الصبح قبل ما تمشي)");
        return r.toString();
    }

    private void batteryTest() {
        if (!connected) {
            Toast.makeText(this, "اتصل بالمحوّل أول", Toast.LENGTH_SHORT).show();
            return;
        }
        if (testing) {
            Toast.makeText(this, "خلّص اختبار القيادة أول", Toast.LENGTH_SHORT).show();
            return;
        }
        if (rpm != null && rpm > 300) {
            Toast.makeText(this, "طفّ المكينة وخلّ المفتاح على ON (الطبلون شغال)", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("فحص البطارية")
                .setMessage("١. المكينة طافية والطبلون شغال (المحوّل متصل)\n٢. اضغط ابدأ\n٣. لما يقول لك، شغّل السيارة خلال ٢٠ ثانية\n\nيقيس كم ينزل الجهد لحظة الدقة: هذي أصدق علامة على صحة البطارية.")
                .setPositiveButton("ابدأ", (d, w) -> new Thread(this::runBatteryTest).start())
                .setNegativeButton("إلغاء", null).show();
    }

    private void runBatteryTest() {
        batteryRunning = true;
        paused = true;
        Obd.sleep(500);
        String result;
        try {
            runOnUiThread(() -> tvElec.setText("أقيس البطارية وهي طافية..."));
            double rest = 0;
            int k = 0;
            for (int i = 0; i < 4; i++) {
                Double v = obd.voltage();
                if (v != null) {
                    rest += v;
                    k++;
                }
                Obd.sleep(150);
            }
            if (k == 0) throw new java.io.IOException("no volt");
            rest /= k;
            final double fr = rest;
            runOnUiThread(() -> {
                tvElec.setText(String.format(Locale.US, "%.2f فولت\n\n▶ شغّل السيارة الحين", fr));
                tvElec.setTextColor(AMBER);
                beep(ToneGenerator.TONE_PROP_BEEP2, 400);
            });
            say("شغّل السيارة الحين");
            double min = rest, after = 0;
            long start = SystemClock.elapsedRealtime(), dipT = 0;
            while (SystemClock.elapsedRealtime() - start < 25000) {
                Double v = obd.voltage();
                if (v == null) continue;
                long now = SystemClock.elapsedRealtime();
                if (v < min) min = v;
                if (dipT == 0 && v < rest - 0.8) dipT = now;
                if (dipT > 0 && now - dipT > 5000) {
                    after = v;
                    break;
                }
            }
            if (dipT == 0) {
                result = "ما لقطت لحظة التشغيل. جرّب مرة ثانية وشغّل السيارة بعد ما يقول لك";
            } else {
                long t = System.currentTimeMillis();
                SharedPreferences.Editor e = prefs.edit();
                if (prefs.contains("bat_rest")) {
                    e.putFloat("bat_prev_rest", prefs.getFloat("bat_rest", 0));
                    e.putLong("bat_prev_time", prefs.getLong("bat_time", 0));
                }
                e.putFloat("bat_rest", (float) rest).putFloat("bat_min", (float) min).putFloat("bat_after", (float) after)
                        .putLong("bat_time", t).apply();
                result = batteryVerdict((float) rest, (float) min, (float) after, prefs.getFloat("bat_prev_rest", 0),
                        prefs.getLong("bat_prev_time", 0), t);
                say(min >= 10.0 ? "البطارية قوية" : min >= 9.6 ? "البطارية بدأت تضعف" : "البطارية ضعيفة، بدّلها قريب");
            }
        } catch (Exception ex) {
            result = "انقطع المحوّل وقت الدقة. إذا تكرر: الجهد نزل كثير (البطارية ضعيفة) أو المحوّل ما يتحمّل";
        }
        paused = false;
        batteryRunning = false;
        final String fres = result;
        runOnUiThread(() -> {
            refreshExtra();
            new AlertDialog.Builder(this).setTitle("نتيجة البطارية").setMessage(fres).setPositiveButton("تم", null).show();
        });
    }

    // ───────────── بصمة المكينة ─────────────

    private JSONObject tripMetrics() throws Exception {
        JSONObject o = new JSONObject();
        if (warmCoolN > 30) o.put("cool", warmCoolSum / warmCoolN);
        if (nTrim > 20) o.put("t1", sumTrim / nTrim);
        if (nTrim2 > 20) o.put("t2", sumTrim2 / nTrim2);
        if (idleN > 30) o.put("idle", idleSum / idleN);
        if (cruiseVN > 20) o.put("volt", cruiseVSum / cruiseVN);
        if (maxTrans != Integer.MIN_VALUE) o.put("trans", maxTrans);
        if (upshifts >= 3) o.put("shift", shiftTimeSum / upshifts);
        if (warmMin > 0) o.put("warm", warmMin);
        return o;
    }

    private void saveTrip() {
        printResult = "";
        long min = (SystemClock.elapsedRealtime() - testStart) / 60000;
        if (min < 8) {
            printResult = "– المشوار أقل من ٨ دقايق، ما انحسب في البصمة";
            return;
        }
        try {
            JSONObject cur = tripMetrics();
            JSONArray base = new JSONArray(prefs.getString("base", "[]"));
            if (base.length() < 3) {
                base.put(cur);
                prefs.edit().putString("base", base.toString()).apply();
                printResult = base.length() < 3 ? "✓ انحفظ المشوار كمرجع (" + base.length() + " من ٣)"
                        : "✓ اكتملت بصمة سيارتك! من المشوار الجاي يقارن";
                return;
            }
            StringBuilder r = new StringBuilder();
            double d;
            if (!Double.isNaN(d = diff(base, cur, "cool")) && d >= 4)
                r.append(String.format(Locale.US, "⚠ حرارة الماء أعلى من عادتها بـ %.0f°: ماء ناقص، ثرموستات، أو المراوح\n", d));
            if (!Double.isNaN(d = diff(base, cur, "t1")) && Math.abs(d) >= 5)
                r.append(String.format(Locale.US, "⚠ خليط الجهة ١ تغيّر %+.0f%% عن عادته%s\n", d, d > 0 ? ": بداية تسريب هوا أو MAF" : ""));
            if (!Double.isNaN(d = diff(base, cur, "t2")) && Math.abs(d) >= 5)
                r.append(String.format(Locale.US, "⚠ خليط الجهة ٢ تغيّر %+.0f%% عن عادته%s\n", d, d > 0 ? ": بداية تسريب هوا أو MAF" : ""));
            if (!Double.isNaN(d = diff(base, cur, "idle")) && Math.abs(d) >= 80)
                r.append(String.format(Locale.US, "⚠ دوران السلانسي تغيّر %+.0f عن عادته: بوابة الهوا أو تسريب\n", d));
            if (!Double.isNaN(d = diff(base, cur, "volt")) && d <= -0.3)
                r.append(String.format(Locale.US, "⚠ شحن الدينمو أقل من عادته بـ %.1f فولت\n", -d));
            if (!Double.isNaN(d = diff(base, cur, "trans")) && d >= 8)
                r.append(String.format(Locale.US, "⚠ القير أحرّ من عادته بـ %.0f°\n", d));
            if (!Double.isNaN(d = diff(base, cur, "warm")) && d >= 3)
                r.append(String.format(Locale.US, "⚠ المكينة صارت تبطّي تسخن (%.0f دقايق زيادة): الثرموستات\n", d));
            if (!Double.isNaN(d = diff(base, cur, "shift")) && d >= 0.3)
                r.append(String.format(Locale.US, "⚠ التبديل صار أبطأ من عادته بـ %.1f ث: زيت القير\n", d));
            printResult = r.length() == 0 ? "✓ المشوار مطابق لبصمة سيارتك — ما فيه شي تغيّر" : r.toString().trim();
            if (r.length() > 0) say("بصمة المكينة: فيه شي تغيّر عن العادة، شوف التقرير");
        } catch (Exception e) {
            printResult = "تعذّر حفظ البصمة";
        }
    }

    /** الحالي ناقص متوسط المرجع */
    private double diff(JSONArray base, JSONObject cur, String key) {
        if (!cur.has(key)) return Double.NaN;
        double sum = 0;
        int n = 0;
        for (int i = 0; i < base.length(); i++) {
            JSONObject b = base.optJSONObject(i);
            if (b != null && b.has(key)) {
                sum += b.optDouble(key);
                n++;
            }
        }
        if (n == 0) return Double.NaN;
        return cur.optDouble(key) - sum / n;
    }

    private String printText() {
        int n = 0;
        try {
            n = new JSONArray(prefs.getString("base", "[]")).length();
        } catch (Exception ignored) {
        }
        String head = n < 3 ? "يتعلّم سيارتك: " + n + " من ٣ مشاوير مرجعية (كل واحد ٨ دقايق أو أكثر)"
                : "البصمة جاهزة ✓ يقارن كل مشوار بعادة سيارتك";
        return printResult.isEmpty() ? head : printResult + "\n" + head + "\n(ضغطة مطوّلة على البطاقة = تصفير)";
    }

    private void refreshExtra() {
        if (tvMech == null) return;
        String m = mechText();
        tvMech.setText(m);
        tvMech.setTextColor(m.contains("✗") ? RED : m.contains("⚠") ? AMBER : TEXT);
        if (!batteryRunning) {
            String e = elecText();
            tvElec.setText(e);
            tvElec.setTextColor(e.contains("✗") ? RED : e.contains("⚠") ? AMBER : TEXT);
        }
        String eg = edgeText();
        tvEdge.setText(eg);
        tvEdge.setTextColor(eg.contains("✗") ? RED : eg.contains("⚠") || eg.contains("⏰") ? AMBER : TEXT);
        String dg = diagText();
        tvDiag.setText(dg);
        tvDiag.setTextColor(dg.contains("✗") ? RED : dg.contains("⚠") ? AMBER : TEXT);
        tvTrip.setText(tripText());
        String mt = maintText();
        tvMaint.setText(mt);
        tvMaint.setTextColor(mt.contains("✗") ? RED : mt.contains("⚠") ? AMBER : TEXT);
        String p = printText();
        tvPrint.setText(p);
        tvPrint.setTextColor(p.contains("⚠") ? AMBER : TEXT);
    }

    /** يرجع [الدرجة، الأسباب] */
    private Object[] score() {
        int s = 100;
        StringBuilder r = new StringBuilder();
        long min = testing || testStart > 0 ? (SystemClock.elapsedRealtime() - testStart) / 60000 : 0;

        if (!stored.isEmpty()) {
            int d = Math.min(45, stored.size() * 15);
            s -= d;
            r.append("✗ أعطال مخزّنة: ").append(TextUtils.join("، ", stored)).append("\n");
        }
        if (!pending.isEmpty()) {
            int d = Math.min(24, pending.size() * 8);
            s -= d;
            r.append("⚠ أعطال معلّقة (بدت تظهر): ").append(TextUtils.join("، ", pending)).append("\n");
        }
        if (stored.isEmpty() && pending.isEmpty()) r.append("✓ ما فيه أعطال\n");

        if (maxCool != Integer.MIN_VALUE) {
            if (maxCool >= 108) {
                s -= 20;
                r.append("✗ الحرارة وصلت ").append(maxCool).append("° (عالية: افحص الماء والمروحة والثرموستات)\n");
            } else if (maxCool >= 104) {
                s -= 8;
                r.append("⚠ الحرارة وصلت ").append(maxCool).append("° (فوق الطبيعي شوي)\n");
            } else if (coolAfter10Min != Integer.MIN_VALUE && coolAfter10Min < 75) {
                s -= 10;
                r.append("⚠ المحرك ما سخن كفاية بعد ١٠ دقايق (").append(coolAfter10Min).append("°): غالباً الثرموستات\n");
            } else {
                r.append("✓ حرارة الماء طبيعية (أعلى ").append(maxCool).append("°)\n");
            }
        }
        if (maxTrans != Integer.MIN_VALUE) {
            if (maxTrans >= 120) {
                s -= 15;
                r.append("✗ حرارة القير وصلت ").append(maxTrans).append("° (عالية: افحص زيت القير ومبرّده)\n");
            } else if (maxTrans >= 110) {
                s -= 6;
                r.append("⚠ حرارة القير وصلت ").append(maxTrans).append("°\n");
            } else {
                r.append("✓ حرارة القير طبيعية (أعلى ").append(maxTrans).append("°)\n");
            }
        } else if (!transSupported) {
            r.append("– حرارة القير: السيارة ما ردّت على الأمر\n");
        }
        if (nTrim > 20) {
            double t = sumTrim / nTrim;
            if (Math.abs(t) > 15) {
                s -= 15;
                r.append(t > 0 ? "✗ الخليط فقير جداً (" : "✗ الخليط غني جداً (").append(String.format(Locale.US, "%+.0f%%", t))
                        .append(t > 0 ? "): تسريب هواء أو MAF أو ضغط بنزين\n" : "): بخاخات أو MAF\n");
            } else if (Math.abs(t) > 10) {
                s -= 7;
                r.append("⚠ تصحيح الخليط مرتفع (").append(String.format(Locale.US, "%+.0f%%", t)).append(")\n");
            } else {
                r.append("✓ خليط البنزين والهواء سليم (").append(String.format(Locale.US, "%+.0f%%", t)).append(")\n");
            }
        }
        if (nVolt > 10) {
            double v = sumVolt / nVolt;
            if (v < 13.2) {
                s -= 10;
                r.append("✗ الشحن ضعيف (").append(String.format(Locale.US, "%.1f", v)).append(" فولت): افحص الدينمو\n");
            } else if (v > 15.0) {
                s -= 10;
                r.append("✗ الشحن عالي (").append(String.format(Locale.US, "%.1f", v)).append(" فولت): منظّم الدينمو\n");
            } else {
                r.append("✓ الدينمو يشحن طبيعي (").append(String.format(Locale.US, "%.1f", v)).append(" فولت)\n");
            }
        }
        if (idleN > 30) {
            double mean = idleSum / idleN;
            double sd = Math.sqrt(Math.max(0, idleSq / idleN - mean * mean));
            if (sd > 80) {
                s -= 5;
                r.append("⚠ الدوران وهي واقفة مو ثابت (±").append(Math.round(sd)).append("): بوابة الهواء أو البواجي\n");
            } else {
                r.append("✓ دوران الهدوء ثابت (").append(Math.round(mean)).append(" RPM)\n");
            }
        }
        int[] mf = misfireWorst();
        if (mf != null && mf[1] >= 10) {
            s -= mf[1] >= 40 ? 15 : 8;
            r.append(mf[1] >= 40 ? "✗" : "⚠").append(" تقطيع في البستم ").append(mf[0]).append(" (").append(mf[1]).append(" مرة)\n");
        }
        if (nTrim2 > 20 && Math.abs(sumTrim2 / nTrim2) > 12) {
            s -= 6;
            r.append("⚠ خليط الجهة الثانية مرتفع (").append(String.format(Locale.US, "%+.0f%%", sumTrim2 / nTrim2)).append(")\n");
        }
        if (idleVN > 20 && cruiseVN > 20 && idleVSum / idleVN < 12.9 && cruiseVSum / cruiseVN >= 13.4) {
            s -= 5;
            r.append("⚠ الدينمو يضعف وهي واقفة (").append(String.format(Locale.US, "%.1f", idleVSum / idleVN)).append(" فولت)\n");
        }
        if (thrBad >= 2) {
            s -= 10;
            r.append("⚠ الثروتل ما يتبع طلب الكمبيوتر (").append(thrBad).append(" مرات)\n");
        }
        String pc = prefs.getString("pump_last", "");
        if (pc.equals("milky")) {
            s -= 40;
            r.append("✗ رغوة/لون حليبي تحت غطا الزيت: ماء داخل الزيت\n");
        } else if (pumpLowCount() >= 2) {
            s -= 10;
            r.append("⚠ ماء الردياتير ينقص بدون سبب ظاهر\n");
        }
        if (monText.contains("✗")) {
            s -= 8;
            r.append("⚠ فيه فحص كمبيوتر ما نجح (شوف فحوصات الكمبيوتر)\n");
        }
        if (idleEpisodes > 0 && badIdleEpisodes * 2 >= idleEpisodes) {
            s -= 12;
            r.append("✗ المراوح ما تلحق تبرّد وأنت واقف\n");
        }
        if (min < 5) r.append("\n(التقييم يصير أدق بعد ٥ دقايق سواقة)");
        return new Object[]{Math.max(0, s), r.toString().trim()};
    }

    private void refresh() {
        vCool.setText(cool != null ? cool + "°" : "--");
        vCool.setTextColor(cool == null ? TEXT : cool >= 106 ? RED : cool >= 100 ? AMBER : TEXT);
        vTrans.setText(trans != null ? trans + "°" : (transSupported ? "--" : "غير مدعوم"));
        vTrans.setTextColor(trans == null ? SUB : trans >= 115 ? RED : trans >= 105 ? AMBER : TEXT);
        vSpeed.setText(speed != null ? String.valueOf(speed) : "--");
        vRpm.setText(rpm != null ? String.valueOf(rpm) : "--");
        vVolt.setText(volt != null ? String.format(Locale.US, "%.1f", volt) : "--");
        vLoad.setText(load != null ? load + "%" : "--");
        if (stft != null && ltft != null) {
            double t = stft + ltft;
            double t2 = stft2 != null && ltft2 != null ? stft2 + ltft2 : Double.NaN;
            double w = Double.isNaN(t2) ? Math.abs(t) : Math.max(Math.abs(t), Math.abs(t2));
            vTrim.setText(Double.isNaN(t2) ? String.format(Locale.US, "%+.0f", t) : String.format(Locale.US, "%+.0f / %+.0f", t, t2));
            vTrim.setTextColor(w > 15 ? RED : w > 10 ? AMBER : TEXT);
        } else {
            vTrim.setText("--");
        }
        vIat.setText(iat != null ? iat + "°" : "--");

        if (testing) {
            long sec = (SystemClock.elapsedRealtime() - testStart) / 1000;
            tvTime.setText(String.format(Locale.US, "الاختبار شغال  •  %02d:%02d  •  %.1f كم", sec / 60, sec % 60, distanceKm));
        } else if (connected) {
            tvTime.setText("متصل. اضغط \"ابدأ الاختبار\" وامشِ");
        }
        refreshExtra();
        if (testing || testStart > 0) {
            Object[] sc = score();
            int s = (Integer) sc[0];
            tvScore.setText(String.valueOf(s));
            tvScore.setTextColor(s >= 85 ? GREEN : s >= 65 ? AMBER : RED);
            tvScoreLabel.setText(s >= 85 ? "ممتازة" : s >= 65 ? "تحتاج انتباه" : "تحتاج فحص عند فني");
            tvReasons.setText((String) sc[1]);
            Object[] g = gearScore();
            int gs = (Integer) g[0];
            tvGearScore.setText(gs < 0 ? "--" : String.valueOf(gs));
            tvGearScore.setTextColor(gs < 0 ? SUB : gs >= 85 ? GREEN : gs >= 65 ? AMBER : RED);
            tvGearInfo.setText((String) g[1]);
            tvGearInfo.setTextColor(TEXT);
            String f = fanText();
            tvFan.setText(f);
            tvFan.setTextColor(f.startsWith("✗") ? RED : f.startsWith("⚠") ? AMBER : f.startsWith("✓") ? GREEN : SUB);
        }
    }

    private void refreshCodes() {
        if (stored.isEmpty() && pending.isEmpty()) {
            tvCodes.setText("✓ ما فيه أعطال  (" + new SimpleDateFormat("HH:mm", Locale.US).format(new Date()) + ")");
            tvCodes.setTextColor(GREEN);
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (String c : stored) {
            String[] d = Dtc.describe(c);
            sb.append("● ").append(c).append("  ").append(d[0]).append("\n   الأسباب: ").append(d[1]).append("\n");
            String dm = Dtc.dashMessage(c);
            if (dm != null) sb.append("   رسالة الطبلون: ").append(dm).append("\n");
        }
        for (String c : pending) {
            if (stored.contains(c)) continue;
            String[] d = Dtc.describe(c);
            sb.append("○ ").append(c).append(" (معلّق — ما ولعت اللمبة للحين)  ").append(d[0]).append("\n   الأسباب: ").append(d[1]).append("\n");
            String dm = Dtc.dashMessage(c);
            if (dm != null) sb.append("   متوقع يطلع في الطبلون: ").append(dm).append("\n");
        }
        if (!freezeText.isEmpty()) sb.append("\n📸 حال السيارة لحظة العطل:\n").append(freezeText);
        tvCodes.setText(sb.toString().trim());
        tvCodes.setTextColor(AMBER);
    }

    private String report() {
        Object[] sc = score();
        long sec = testStart > 0 ? (SystemClock.elapsedRealtime() - testStart) / 1000 : 0;
        StringBuilder sb = new StringBuilder();
        sb.append("تقرير اختبار القيادة — فورد إيدج\n");
        sb.append(new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date())).append("\n");
        sb.append(String.format(Locale.US, "المدة: %d دقيقة  •  المسافة: %.1f كم\n", sec / 60, distanceKm));
        sb.append("التقييم: ").append(sc[0]).append(" / 100\n\n");
        sb.append(sc[1]).append("\n\n");
        if (maxCool != Integer.MIN_VALUE) sb.append("أعلى حرارة ماء: ").append(maxCool).append("°\n");
        if (maxTrans != Integer.MIN_VALUE) sb.append("أعلى حرارة قير: ").append(maxTrans).append("°\n");
        if (maxRpm > 0) sb.append("أعلى دوران: ").append(maxRpm).append("\n");
        Object[] g = gearScore();
        sb.append("\nسلاسة القير: ").append((Integer) g[0] < 0 ? "غير مكتمل" : g[0] + " / 100").append("\n").append(g[1]).append("\n");
        sb.append("\nالمراوح: ").append(fanText()).append("\n");
        sb.append("\nالميكانيكا:\n").append(mechText()).append("\n");
        sb.append("\nالكهرباء:\n").append(elecText()).append("\n");
        sb.append("\nبصمة المكينة:\n").append(printText()).append("\n");
        sb.append("\nحارس إيدج:\n").append(edgeText()).append("\n");
        sb.append("\nفحوصات الكمبيوتر:\n").append(diagText()).append("\n");
        sb.append("\nالبنزين:\n").append(tripText()).append("\n");
        sb.append("\nالصيانة:\n").append(maintText()).append("\n");
        if (!freezeText.isEmpty()) sb.append("\nلحظة العطل:\n").append(freezeText).append("\n");
        if (!absText.isEmpty()) sb.append("\nالفرامل ABS:\n").append(absText).append("\n");
        if (!stored.isEmpty() || !pending.isEmpty()) {
            sb.append("\nالأعطال:\n");
            for (String c : stored) sb.append("• ").append(c).append(" — ").append(Dtc.describe(c)[0]).append("\n");
            for (String c : pending)
                if (!stored.contains(c)) sb.append("• ").append(c).append(" (معلّق) — ").append(Dtc.describe(c)[0]).append("\n");
        }
        return sb.toString().trim();
    }

    private void shareReport() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, report());
        startActivity(Intent.createChooser(i, "مشاركة التقرير"));
    }

    @Override
    protected void onDestroy() {
        stop = true;
        if (bb != null) bb.save();
        obd.close();
        if (tone != null) tone.release();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
