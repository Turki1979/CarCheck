package com.turki.carcheck;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** اتصال بمحوّل ELM327 (بلوتوث كلاسيك) وأوامر OBD. */
public class Obd {

    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;

    public void connect(String address) throws IOException {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) throw new IOException("البلوتوث مقفل");
        BluetoothDevice dev = ad.getRemoteDevice(address);
        try {
            ad.cancelDiscovery();
        } catch (SecurityException ignored) {
        }
        try {
            socket = dev.createRfcommSocketToServiceRecord(SPP);
            socket.connect();
        } catch (IOException e) {
            close();
            socket = dev.createInsecureRfcommSocketToServiceRecord(SPP);
            socket.connect();
        }
        in = socket.getInputStream();
        out = socket.getOutputStream();
    }

    /** تهيئة المحوّل. يرجع true إذا رد على السيارة. */
    public boolean init() throws IOException {
        cmd("ATZ", 3000);
        sleep(600);
        cmd("ATE0", 1500);
        cmd("ATL0", 1500);
        cmd("ATS0", 1500);
        cmd("ATH0", 1500);
        cmd("ATSP0", 1500);
        String r = cmd("0100", 10000);
        boolean ok = r.contains("4100");
        if (ok) {
            // نوجّه الأوامر لكمبيوتر المحرك مباشرة (يحتاجه أمر حرارة القير الخاص بفورد)
            String h = cmd("ATSH7E0", 1500);
            if (!h.contains("OK")) cmd("ATSH7DF", 1500);
        }
        return ok;
    }

    public synchronized String cmd(String c, long timeoutMs) throws IOException {
        if (out == null || in == null) throw new IOException("غير متصل");
        while (in.available() > 0) in.read();
        out.write((c + "\r").getBytes());
        out.flush();
        StringBuilder sb = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            if (in.available() > 0) {
                int ch = in.read();
                if (ch < 0) throw new IOException("انقطع الاتصال");
                if (ch == '>') break;
                sb.append((char) ch);
            } else {
                sleep(10);
            }
        }
        return sb.toString().replace("SEARCHING...", "").toUpperCase(Locale.US);
    }

    /** ينظّف الرد ويشيل المسافات */
    static String clean(String r) {
        return r.replaceAll("\\s", "");
    }

    /** بايتات البيانات بعد البادئة (مثلاً "4105") */
    public int[] pid(String command, String prefix, int count) throws IOException {
        String r = clean(cmd(command, 1500));
        int i = r.indexOf(prefix);
        if (i < 0) return null;
        int s = i + prefix.length();
        if (r.length() < s + count * 2) return null;
        int[] b = new int[count];
        try {
            for (int k = 0; k < count; k++) b[k] = Integer.parseInt(r.substring(s + k * 2, s + k * 2 + 2), 16);
        } catch (NumberFormatException e) {
            return null;
        }
        return b;
    }

    private boolean atrvOk = true;

    /** جهد البطارية: من المحوّل (ATRV) وإذا ما ضبط من كمبيوتر المحرك (0142) */
    public Double voltage() throws IOException {
        if (atrvOk) {
            String r = cmd("ATRV", 1500);
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}[.,]\\d{1,2})").matcher(r);
            if (m.find()) {
                try {
                    double v = Double.parseDouble(m.group(1).replace(',', '.'));
                    if (v > 5 && v < 20) return v;
                } catch (NumberFormatException ignored) {
                }
            }
            atrvFails++;
            if (atrvFails >= 3) atrvOk = false;
        }
        int[] b = pid("0142", "4142", 2);
        if (b != null) {
            double v = (b[0] * 256 + b[1]) / 1000.0;
            if (v > 5 && v < 20) return v;
        }
        return null;
    }

    private int atrvFails;

    /** يغيّر العنوان (7E0 كمبيوتر المحرك، 7E1 كمبيوتر القير) */
    public void header(String h) throws IOException {
        cmd("ATSH" + h, 1000);
    }

    /** قراءة أكواد الأعطال. mode = "03" (مخزّنة) أو "07" (معلّقة) أو "0A" (دائمة) */
    public List<String> dtcs(String mode) throws IOException {
        String raw = cmd(mode, 5000);
        String respPrefix = Integer.toHexString(Integer.parseInt(mode, 16) + 0x40).toUpperCase(Locale.US);
        List<String> out = new ArrayList<>();
        if (raw.contains("NODATA")) return out;
        // نشيل أسطر الطول (مثل 00A) وبادئات الأسطر (0: 1: ...)
        StringBuilder sb = new StringBuilder();
        for (String line : raw.split("[\\r\\n]+")) {
            String l = line.trim();
            if (l.isEmpty()) continue;
            if (l.matches("[0-9A-F]{3}")) continue;
            l = l.replaceFirst("^[0-9A-F]:", "");
            sb.append(l.replaceAll("\\s", ""));
        }
        String d = sb.toString();
        int i = d.indexOf(respPrefix);
        while (i >= 0 && i + 4 <= d.length()) {
            int pos = i + 2;
            int n;
            try {
                n = Integer.parseInt(d.substring(pos, pos + 2), 16);
            } catch (NumberFormatException e) {
                break;
            }
            int end;
            if (pos + 2 + n * 4 <= d.length()) {
                // شبكة CAN: أول بايت = عدد الأكواد
                pos += 2;
                end = pos + n * 4;
            } else {
                // بروتوكول قديم: أزواج بايتات لين النهاية
                end = d.length() - ((d.length() - pos) % 4);
            }
            for (int k = pos; k + 4 <= end; k += 4) {
                String c = d.substring(k, k + 4);
                if (c.equals("0000")) continue;
                String dtc = decode(c);
                if (dtc != null && !out.contains(dtc)) out.add(dtc);
            }
            i = d.indexOf(respPrefix, end);
        }
        return out;
    }

    /** يجمع أسطر الرد المتعدد في سطر واحد */
    static String joinFrames(String raw) {
        StringBuilder sb = new StringBuilder();
        for (String line : raw.split("[\\r\\n]+")) {
            String l = line.trim();
            if (l.isEmpty()) continue;
            if (l.matches("[0-9A-F]{3}")) continue;
            l = l.replaceFirst("^[0-9A-F]:", "");
            sb.append(l.replaceAll("\\s", ""));
        }
        return sb.toString();
    }

    /** عداد التقطيع لبستم (Mode 06). يرجع {معدّل آخر ١٠ تشغيلات، التشغيلة الحالية} أو null */
    public int[] misfire(int cyl) throws IOException {
        String mid = Integer.toHexString(0xA1 + cyl).toUpperCase(Locale.US);
        String raw = cmd("06" + mid, 2500);
        if (raw.contains("NODATA") || raw.contains("7F06")) return null;
        String d = joinFrames(raw);
        int i = d.indexOf("46" + mid);
        if (i < 0) return null;
        String t = d.substring(i + 4);
        int ewma = -1, cur = -1;
        // كل اختبار: TID + وحدة 24 (عدّاد) + القيمة (بايتين)
        for (int k = 0; k + 8 <= t.length(); k += 2) {
            String id = t.substring(k, k + 4);
            try {
                if (ewma < 0 && id.equals("0B24")) ewma = Integer.parseInt(t.substring(k + 4, k + 8), 16);
                else if (cur < 0 && id.equals("0C24")) cur = Integer.parseInt(t.substring(k + 4, k + 8), 16);
            } catch (NumberFormatException ignored) {
            }
        }
        if (ewma < 0 && cur < 0) return null;
        return new int[]{Math.max(0, ewma), Math.max(0, cur)};
    }

    /** نتائج اختبار Mode 06 لنظام: كل عنصر {TID، القيمة، الحد الأدنى، الحد الأعلى} أو null */
    public List<int[]> monitor(int mid) throws IOException {
        String m = String.format(Locale.US, "%02X", mid);
        String raw = cmd("06" + m, 2500);
        if (raw.contains("NODATA") || raw.contains("7F06")) return null;
        String d = joinFrames(raw);
        int i = d.indexOf("46" + m);
        if (i < 0) return null;
        List<int[]> out = new ArrayList<>();
        int pos = i + 2;
        // كل سجل: MID TID UASID القيمة(٢) الأدنى(٢) الأعلى(٢) = ٩ بايت
        while (pos + 18 <= d.length() && d.startsWith(m, pos)) {
            try {
                int tid = Integer.parseInt(d.substring(pos + 2, pos + 4), 16);
                int val = Integer.parseInt(d.substring(pos + 6, pos + 10), 16);
                int mn = Integer.parseInt(d.substring(pos + 10, pos + 14), 16);
                int mx = Integer.parseInt(d.substring(pos + 14, pos + 18), 16);
                out.add(new int[]{tid, val, mn, mx});
            } catch (NumberFormatException e) {
                break;
            }
            pos += 18;
        }
        return out.isEmpty() ? null : out;
    }

    /** أكواد كمبيوتر الـABS (العنوان 760). كل عنصر {الكود، "s" مخزّن أو "p" معلّق}. null = ما ردّ */
    public List<String[]> absCodes() throws IOException {
        List<String[]> out = new ArrayList<>();
        cmd("ATSH760", 1000);
        cmd("ATCRA768", 1000);
        try {
            // الطريقة الحديثة (UDS 19 02)
            String d = joinFrames(cmd("1902FF", 4000));
            int i = d.indexOf("5902");
            if (i >= 0) {
                for (int k = i + 6; k + 8 <= d.length(); k += 8) {
                    String h = d.substring(k, k + 4);
                    if (h.equals("0000")) continue;
                    int st;
                    try {
                        st = Integer.parseInt(d.substring(k + 6, k + 8), 16);
                    } catch (NumberFormatException e) {
                        break;
                    }
                    String c = decode(h);
                    if (c == null) continue;
                    boolean stored = (st & 0x09) != 0;
                    boolean pend = (st & 0x04) != 0;
                    if (!stored && !pend) continue;
                    out.add(new String[]{c, stored ? "s" : "p"});
                }
                return out;
            }
            // الطريقة القديمة (KWP 18)
            d = joinFrames(cmd("1800FF00", 4000));
            i = d.indexOf("58");
            if (i >= 0 && i + 4 <= d.length()) {
                int n;
                try {
                    n = Integer.parseInt(d.substring(i + 2, i + 4), 16);
                } catch (NumberFormatException e) {
                    return null;
                }
                int pos = i + 4;
                for (int k = 0; k < n && pos + 6 <= d.length(); k++, pos += 6) {
                    String h = d.substring(pos, pos + 4);
                    if (h.equals("0000")) continue;
                    String c = decode(h);
                    if (c != null) out.add(new String[]{c, "s"});
                }
                return out;
            }
            return null;
        } finally {
            cmd("ATCRA", 1000);
            cmd("ATSH7E0", 1000);
        }
    }

    static String decode(String hex4) {
        try {
            int a = Integer.parseInt(hex4.substring(0, 2), 16);
            char sys = "PCBU".charAt((a >> 6) & 3);
            int d1 = (a >> 4) & 3;
            return sys + "" + d1 + Integer.toHexString(a & 0xF).toUpperCase(Locale.US) + hex4.substring(2);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean clearCodes() throws IOException {
        String r = clean(cmd("04", 5000));
        return r.contains("44");
    }

    public void close() {
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {
        }
        socket = null;
        in = null;
        out = null;
    }

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
