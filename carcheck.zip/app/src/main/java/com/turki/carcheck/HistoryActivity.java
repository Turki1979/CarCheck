package com.turki.carcheck;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.List;
import java.util.Locale;

/** سجل المشاوير + الرسم البياني + الصندوق الأسود */
public class HistoryActivity extends Activity {

    private static final int BG = 0xFF0A1424, CARD = 0x14FFFFFF, STROKE = 0x29FFFFFF;
    private static final int TEXT = 0xFFEEF3FA, SUB = 0xFF9FB2CC;
    static final int C_COOL = 0xFFFF6B6B, C_TRANS = 0xFFFFB020, C_SPEED = 0xFF4FA3FF, C_GREEN = 0xFF4ADE80, C_RPM = 0xFFB28DFF;

    private SharedPreferences prefs;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable box(int fill, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), STROKE);
        return g;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.25f);
        return t;
    }

    private LinearLayout card(LinearLayout root, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(box(CARD, 18));
        c.addView(text(title, 14, SUB));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        root.addView(c, lp);
        return c;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("carcheck", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        sv.addView(root);
        TextView title = text("السجل والصندوق الأسود", 22, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        JSONArray trips;
        try {
            trips = new JSONArray(prefs.getString("trips", "[]"));
        } catch (Exception e) {
            trips = new JSONArray();
        }

        // تطور التقييم
        LinearLayout c1 = card(root, "تقييم المكينة والقير عبر المشاوير");
        if (trips.length() >= 2) {
            int n = Math.min(30, trips.length());
            float[] x = new float[n], s = new float[n], g = new float[n];
            for (int i = 0; i < n; i++) {
                JSONObject t = trips.optJSONObject(trips.length() - n + i);
                x[i] = i + 1;
                s[i] = (float) t.optDouble("score", Double.NaN);
                double gs = t.optDouble("gear", -1);
                g[i] = gs < 0 ? Float.NaN : (float) gs;
            }
            Graph gr = new Graph(this);
            gr.setX(x, "مشوار");
            gr.add("المكينة", C_GREEN, s);
            gr.add("القير", C_TRANS, g);
            c1.addView(gr);
        } else {
            c1.addView(text("يطلع بعد مشوارين أو أكثر", 13, SUB));
        }

        // آخر مشوار
        LinearLayout c2 = card(root, "آخر مشوار: الحرارة والسرعة");
        try {
            JSONArray se = new JSONArray(prefs.getString("series", "[]"));
            if (se.length() >= 3) {
                int n = se.length();
                float[] x = new float[n], co = new float[n], tr = new float[n], sp = new float[n];
                for (int i = 0; i < n; i++) {
                    JSONArray r = se.getJSONArray(i);
                    x[i] = (float) r.optDouble(0);
                    co[i] = (float) r.optDouble(1, Double.NaN);
                    tr[i] = (float) r.optDouble(2, Double.NaN);
                    sp[i] = (float) r.optDouble(3, Double.NaN);
                }
                Graph gr = new Graph(this);
                gr.setX(x, "دقيقة");
                gr.add("الماء", C_COOL, co);
                gr.add("القير", C_TRANS, tr);
                gr.add("السرعة", C_SPEED, sp);
                c2.addView(gr);
            } else {
                c2.addView(text("سوِّ اختبار قيادة ويطلع هنا", 13, SUB));
            }
        } catch (Exception e) {
            c2.addView(text("ما فيه بيانات", 13, SUB));
        }

        // قائمة المشاوير
        LinearLayout c3 = card(root, "المشاوير");
        if (trips.length() == 0) c3.addView(text("ما فيه مشاوير محفوظة", 13, SUB));
        for (int i = trips.length() - 1; i >= 0 && i >= trips.length() - 30; i--) {
            JSONObject t = trips.optJSONObject(i);
            if (t == null) continue;
            StringBuilder sb = new StringBuilder();
            sb.append(t.optString("date")).append("  •  ").append(t.optInt("min")).append(" د  •  ")
                    .append(String.format(Locale.US, "%.1f كم", t.optDouble("km")));
            sb.append("\nالتقييم ").append(t.optInt("score"));
            if (t.optInt("gear", -1) >= 0) sb.append("  •  القير ").append(t.optInt("gear"));
            if (t.has("cool")) sb.append("  •  ماء ").append(t.optInt("cool")).append("°");
            if (t.has("trans")) sb.append("  •  قير ").append(t.optInt("trans")).append("°");
            if (t.optDouble("fuel", 0) > 0)
                sb.append(String.format(Locale.US, "\n⛽ %.1f لتر  •  %.2f ريال", t.optDouble("fuel"), t.optDouble("cost")));
            if (t.optDouble("l100", 0) > 0) sb.append(String.format(Locale.US, "  •  %.1f ل/100كم", t.optDouble("l100")));
            TextView tv = text(sb.toString(), 13, TEXT);
            tv.setPadding(0, dp(8), 0, dp(8));
            c3.addView(tv);
        }

        // الصندوق الأسود
        LinearLayout c4 = card(root, "الصندوق الأسود (دقيقة قبل الحدث و٣٠ ثانية بعده)");
        List<File> files = new BlackBox(getFilesDir()).files();
        if (files.isEmpty()) c4.addView(text("ما فيه تسجيلات. يتسجّل لحاله عند أي تنبيه أو عطل، أو بزر \"سجّل اللحظة\"", 13, SUB));
        for (File f : files) {
            Object[] o = BlackBox.load(f);
            TextView tv = text("● " + o[1] + "\n   " + o[0], 13, TEXT);
            tv.setPadding(dp(10), dp(10), dp(10), dp(10));
            tv.setBackground(box(0x0AFFFFFF, 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            c4.addView(tv, lp);
            tv.setOnClickListener(v -> showEvent(f));
        }

        setContentView(sv);
    }

    @SuppressWarnings("unchecked")
    private void showEvent(File f) {
        Object[] o = BlackBox.load(f);
        List<float[]> rows = (List<float[]>) o[2];
        int n = rows.size();
        float[] x = new float[n];
        float[][] col = new float[BlackBox.COLS.length][n];
        for (int i = 0; i < n; i++) {
            x[i] = rows.get(i)[0];
            for (int k = 1; k < BlackBox.COLS.length; k++) col[k][i] = rows.get(i)[k];
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        box.setBackgroundColor(BG);
        box.addView(text(o[0] + "\n" + o[1] + "\nالخط الأحمر = لحظة الحدث", 13, TEXT));
        Graph g1 = new Graph(this);
        g1.setX(x, "ث");
        g1.add("السرعة", C_SPEED, col[1]);
        g1.add("الدوران", C_RPM, col[2]);
        g1.add("الحمل", C_GREEN, col[5]);
        g1.setMark(0);
        box.addView(g1);
        Graph g2 = new Graph(this);
        g2.setX(x, "ث");
        g2.add("الماء", C_COOL, col[3]);
        g2.add("القير", C_TRANS, col[4]);
        g2.add("الجهد", 0xFFEEF3FA, col[6]);
        g2.setMark(0);
        box.addView(g2);
        Graph g3 = new Graph(this);
        g3.setX(x, "ث");
        g3.add("ثروتل مطلوب", C_GREEN, col[9]);
        g3.add("ثروتل فعلي", C_COOL, col[10]);
        g3.add("خليط ج١", C_SPEED, col[7]);
        g3.add("خليط ج٢", C_TRANS, col[8]);
        g3.setMark(0);
        box.addView(g3);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new AlertDialog.Builder(this)
                .setView(sv)
                .setPositiveButton("اسأل الذكاء", (d, w) -> Ai.ask(this, "تسجيل الصندوق الأسود (الوقت بالثواني، صفر = لحظة الحدث):\n" + BlackBox.text(f)))
                .setNeutralButton("مشاركة", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, BlackBox.text(f));
                    startActivity(Intent.createChooser(i, "مشاركة التسجيل"));
                })
                .setNegativeButton("حذف", (d, w) -> {
                    f.delete();
                    recreate();
                })
                .show();
    }
}
